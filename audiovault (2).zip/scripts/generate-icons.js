import fs from 'fs';
import path from 'path';
import sharp from 'sharp';

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Beautiful soundwave/audio vault SVG
const standardSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="50%" stop-color="#1e1b4b" />
      <stop offset="100%" stop-color="#090d16" />
    </linearGradient>
    <linearGradient id="accent" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" />
      <stop offset="50%" stop-color="#818cf8" />
      <stop offset="100%" stop-color="#c084fc" />
    </linearGradient>
    <linearGradient id="wave" x1="0%" y1="100%" x2="0%" y2="0%">
      <stop offset="0%" stop-color="#06b6d4" />
      <stop offset="50%" stop-color="#3b82f6" />
      <stop offset="100%" stop-color="#a855f7" />
    </linearGradient>
    <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="12" result="blur" />
      <feComposite in="SourceGraphic" in2="blur" operator="over" />
    </filter>
  </defs>
  
  <!-- Outer Rounded Container -->
  <rect width="512" height="512" rx="112" fill="url(#bg)" />
  <rect width="510" height="510" x="1" y="1" rx="111" fill="none" stroke="rgba(255,255,255,0.12)" stroke-width="2" />
  
  <!-- Subtle circular groove ring like vinyl/disc -->
  <circle cx="256" cy="256" r="190" fill="none" stroke="rgba(255,255,255,0.04)" stroke-width="3" />
  <circle cx="256" cy="256" r="150" fill="none" stroke="rgba(255,255,255,0.04)" stroke-width="2" />
  
  <!-- Vault / Audio Headphones + Sound Wave Logo -->
  <!-- Headphone Band -->
  <path d="M 140 256 C 140 160, 200 120, 256 120 C 312 120, 372 160, 372 256" 
        fill="none" stroke="url(#accent)" stroke-width="24" stroke-linecap="round" filter="url(#glow)" />
        
  <!-- Headphone Ear Pads -->
  <rect x="116" y="230" width="46" height="84" rx="23" fill="url(#accent)" />
  <rect x="350" y="230" width="46" height="84" rx="23" fill="url(#accent)" />

  <!-- Dynamic Waveform inside center -->
  <g transform="translate(186, 210)" fill="url(#wave)">
    <rect x="0" y="32" width="10" height="40" rx="5" />
    <rect x="18" y="18" width="10" height="68" rx="5" />
    <rect x="36" y="4" width="10" height="96" rx="5" />
    <rect x="54" y="24" width="10" height="56" rx="5" />
    <rect x="72" y="8" width="10" height="88" rx="5" />
    <rect x="90" y="20" width="10" height="64" rx="5" />
    <rect x="108" y="34" width="10" height="36" rx="5" />
    <rect x="126" y="42" width="10" height="20" rx="5" />
  </g>
  
  <!-- Sparkle / Recording Dot -->
  <circle cx="360" cy="150" r="12" fill="#ef4444" filter="url(#glow)" />
  <circle cx="360" cy="150" r="6" fill="#ffffff" />
</svg>`;

// Maskable icon has 15% safe padding
const maskableSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bg2" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="50%" stop-color="#1e1b4b" />
      <stop offset="100%" stop-color="#090d16" />
    </linearGradient>
    <linearGradient id="accent2" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#38bdf8" />
      <stop offset="50%" stop-color="#818cf8" />
      <stop offset="100%" stop-color="#c084fc" />
    </linearGradient>
    <linearGradient id="wave2" x1="0%" y1="100%" x2="0%" y2="0%">
      <stop offset="0%" stop-color="#06b6d4" />
      <stop offset="50%" stop-color="#3b82f6" />
      <stop offset="100%" stop-color="#a855f7" />
    </linearGradient>
  </defs>
  
  <!-- Full bleed for maskable -->
  <rect width="512" height="512" fill="url(#bg2)" />
  
  <!-- Content scaled inside safe-zone (80% circle) -->
  <g transform="translate(51, 51) scale(0.8)">
    <circle cx="256" cy="256" r="190" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="4" />
    <path d="M 140 256 C 140 160, 200 120, 256 120 C 312 120, 372 160, 372 256" 
          fill="none" stroke="url(#accent2)" stroke-width="26" stroke-linecap="round" />
          
    <rect x="114" y="228" width="48" height="88" rx="24" fill="url(#accent2)" />
    <rect x="350" y="228" width="48" height="88" rx="24" fill="url(#accent2)" />

    <g transform="translate(186, 210)" fill="url(#wave2)">
      <rect x="0" y="32" width="10" height="40" rx="5" />
      <rect x="18" y="18" width="10" height="68" rx="5" />
      <rect x="36" y="4" width="10" height="96" rx="5" />
      <rect x="54" y="24" width="10" height="56" rx="5" />
      <rect x="72" y="8" width="10" height="88" rx="5" />
      <rect x="90" y="20" width="10" height="64" rx="5" />
      <rect x="108" y="34" width="10" height="36" rx="5" />
      <rect x="126" y="42" width="10" height="20" rx="5" />
    </g>
    
    <circle cx="360" cy="150" r="12" fill="#ef4444" />
    <circle cx="360" cy="150" r="6" fill="#ffffff" />
  </g>
</svg>`;

async function run() {
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), standardSvg);
  
  await sharp(Buffer.from(standardSvg))
    .resize(192, 192)
    .png()
    .toFile(path.join(publicDir, 'pwa-192x192.png'));

  await sharp(Buffer.from(standardSvg))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-512x512.png'));

  await sharp(Buffer.from(standardSvg))
    .resize(180, 180)
    .png()
    .toFile(path.join(publicDir, 'apple-touch-icon.png'));

  await sharp(Buffer.from(maskableSvg))
    .resize(512, 512)
    .png()
    .toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));

  console.log('PWA icons created successfully.');
}

run().catch(console.error);
