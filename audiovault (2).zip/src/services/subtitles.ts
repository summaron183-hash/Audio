import { AudioTrack } from '../types';
import { getAudioBlob, saveTrackSubtitles } from './storage';

export interface SubtitleCue {
  start: number;
  end: number;
  text: string;
}

// Convert a Blob to base64
export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const dataUrl = reader.result as string;
      const base64 = dataUrl.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
  });
}

// Parse SRT or VTT subtitle format
export function parseSrtOrVtt(content: string): SubtitleCue[] {
  const cues: SubtitleCue[] = [];
  const lines = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');

  let i = 0;
  while (i < lines.length) {
    const line = lines[i].trim();

    // Check if this line is a timestamp line (e.g. 00:00:01,000 --> 00:00:04,000 or 00:01.000 --> 00:04.000)
    if (line.includes('-->')) {
      const parts = line.split('-->');
      const startSec = parseTimestamp(parts[0].trim());
      const endSec = parseTimestamp(parts[1].trim());

      let text = '';
      i++;
      while (i < lines.length && lines[i].trim() !== '') {
        text += (text ? ' ' : '') + lines[i].trim();
        i++;
      }

      if (Number.isFinite(startSec) && Number.isFinite(endSec) && text) {
        cues.push({
          start: startSec,
          end: Math.max(endSec, startSec + 1),
          text: text.replace(/<[^>]*>/g, ''), // Strip tags
        });
      }
    } else {
      i++;
    }
  }

  return cues;
}

function parseTimestamp(timeStr: string): number {
  const clean = timeStr.replace(',', '.');
  const parts = clean.split(':').map((p) => parseFloat(p));
  if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  } else if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  } else if (parts.length === 1) {
    return parts[0];
  }
  return 0;
}

// Fetch subtitles from server API (with Gemini AI) and store permanently in IndexedDB for offline play
export async function generateAndCacheSubtitles(
  track: AudioTrack
): Promise<SubtitleCue[]> {
  const blob = await getAudioBlob(track.id);
  if (!blob) {
    throw new Error('Audio file not found in browser storage');
  }

  // Convert to base64
  const audioBase64 = await blobToBase64(blob);

  const res = await fetch('/api/transcribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      audioBase64,
      mimeType: track.type || 'audio/mp3',
      trackTitle: track.title,
    }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error || 'Failed to generate English subtitles');
  }

  const data = await res.json();
  const subtitles: SubtitleCue[] = data.subtitles || [];

  if (subtitles.length > 0) {
    // Save to IndexedDB so it is permanently offline accessible!
    await saveTrackSubtitles(track.id, subtitles, 'ai');
  }

  return subtitles;
}

// Batch download subtitles for all recordings while connected to wifi/data
export async function downloadAllEnglishSubtitles(
  tracks: AudioTrack[],
  onProgress: (current: number, total: number, trackName: string) => void
): Promise<{ success: number; failed: number }> {
  let success = 0;
  let failed = 0;

  const needed = tracks.filter((t) => !t.subtitles || t.subtitles.length === 0);

  for (let i = 0; i < needed.length; i++) {
    const track = needed[i];
    onProgress(i + 1, needed.length, track.title);
    try {
      await generateAndCacheSubtitles(track);
      success++;
    } catch (err) {
      console.warn(`Could not generate subtitles for ${track.title}:`, err);
      failed++;
    }
  }

  return { success, failed };
}
