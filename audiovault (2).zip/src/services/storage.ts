import { AudioTrack } from '../types';

const DB_NAME = 'VocalVaultDB';
const DB_VERSION = 1;
const TRACKS_STORE = 'tracks';
const BLOBS_STORE = 'audioBlobs';
const SETTINGS_STORE = 'settings';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(TRACKS_STORE)) {
        const trackStore = db.createObjectStore(TRACKS_STORE, { keyPath: 'id' });
        trackStore.createIndex('folder', 'folder', { unique: false });
        trackStore.createIndex('name', 'name', { unique: false });
        trackStore.createIndex('dateAdded', 'dateAdded', { unique: false });
        trackStore.createIndex('favorite', 'favorite', { unique: false });
      }
      if (!db.objectStoreNames.contains(BLOBS_STORE)) {
        db.createObjectStore(BLOBS_STORE);
      }
      if (!db.objectStoreNames.contains(SETTINGS_STORE)) {
        db.createObjectStore(SETTINGS_STORE);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllTracks(): Promise<AudioTrack[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TRACKS_STORE, 'readonly');
    const store = tx.objectStore(TRACKS_STORE);
    const request = store.getAll();

    request.onsuccess = () => {
      resolve(request.result as AudioTrack[]);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function getAudioBlob(trackId: string): Promise<Blob | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(BLOBS_STORE, 'readonly');
    const store = tx.objectStore(BLOBS_STORE);
    const request = store.get(trackId);

    request.onsuccess = () => {
      resolve(request.result || null);
    };
    request.onerror = () => reject(request.error);
  });
}

export async function addTracksWithBlobs(
  items: { track: AudioTrack; blob: Blob }[],
  onProgress?: (processed: number, total: number) => void
): Promise<void> {
  if (items.length === 0) return;
  const db = await openDB();

  // Batch insert in manageable transactions to avoid browser transaction timeouts
  const batchSize = 25;
  for (let i = 0; i < items.length; i += batchSize) {
    const chunk = items.slice(i, i + batchSize);
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction([TRACKS_STORE, BLOBS_STORE], 'readwrite');
      const trackStore = tx.objectStore(TRACKS_STORE);
      const blobStore = tx.objectStore(BLOBS_STORE);

      chunk.forEach(({ track, blob }) => {
        trackStore.put(track);
        blobStore.put(blob, track.id);
      });

      tx.oncomplete = () => {
        if (onProgress) {
          onProgress(Math.min(i + chunk.length, items.length), items.length);
        }
        resolve();
      };
      tx.onerror = () => reject(tx.error);
    });
  }
}

export async function updateTrack(track: AudioTrack): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TRACKS_STORE, 'readwrite');
    const store = tx.objectStore(TRACKS_STORE);
    const req = store.put(track);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function toggleFavorite(trackId: string): Promise<boolean> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TRACKS_STORE, 'readwrite');
    const store = tx.objectStore(TRACKS_STORE);
    const getReq = store.get(trackId);

    getReq.onsuccess = () => {
      const track = getReq.result as AudioTrack | undefined;
      if (!track) {
        resolve(false);
        return;
      }
      track.favorite = !track.favorite;
      const putReq = store.put(track);
      putReq.onsuccess = () => resolve(!!track.favorite);
      putReq.onerror = () => reject(putReq.error);
    };
    getReq.onerror = () => reject(getReq.error);
  });
}

export async function deleteTrack(trackId: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([TRACKS_STORE, BLOBS_STORE], 'readwrite');
    tx.objectStore(TRACKS_STORE).delete(trackId);
    tx.objectStore(BLOBS_STORE).delete(trackId);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function deleteTracksByFolder(folderPath: string): Promise<number> {
  const tracks = await getAllTracks();
  const toDelete = tracks.filter(
    (t) => t.folder === folderPath || t.folder.startsWith(folderPath + '/')
  );

  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([TRACKS_STORE, BLOBS_STORE], 'readwrite');
    const trackStore = tx.objectStore(TRACKS_STORE);
    const blobStore = tx.objectStore(BLOBS_STORE);

    toDelete.forEach((t) => {
      trackStore.delete(t.id);
      blobStore.delete(t.id);
    });

    tx.oncomplete = () => resolve(toDelete.length);
    tx.onerror = () => reject(tx.error);
  });
}

export async function renameTrack(trackId: string, newTitle: string): Promise<AudioTrack | null> {
  const tracks = await getAllTracks();
  const track = tracks.find((t) => t.id === trackId);
  if (!track) return null;

  const ext = track.name.includes('.') ? '.' + track.name.split('.').pop() : '';
  const cleanTitle = newTitle.trim();
  const updatedTrack: AudioTrack = {
    ...track,
    title: cleanTitle,
    name: cleanTitle + ext,
  };

  await updateTrack(updatedTrack);
  return updatedTrack;
}

export async function renameFolder(oldFolder: string, newFolder: string): Promise<number> {
  const cleanOld = oldFolder.trim();
  const cleanNew = newFolder.trim();
  if (!cleanOld || !cleanNew || cleanOld === cleanNew) return 0;

  const tracks = await getAllTracks();
  const affected = tracks.filter(
    (t) => t.folder === cleanOld || t.folder.startsWith(cleanOld + '/')
  );

  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TRACKS_STORE, 'readwrite');
    const store = tx.objectStore(TRACKS_STORE);

    affected.forEach((t) => {
      let updatedFolder = cleanNew;
      if (t.folder.startsWith(cleanOld + '/')) {
        updatedFolder = cleanNew + t.folder.slice(cleanOld.length);
      }
      const updatedTrack: AudioTrack = {
        ...t,
        folder: updatedFolder,
        path: updatedFolder + '/' + t.name,
      };
      store.put(updatedTrack);
    });

    tx.oncomplete = () => resolve(affected.length);
    tx.onerror = () => reject(tx.error);
  });
}

export async function moveTrack(trackId: string, destinationFolder: string): Promise<AudioTrack | null> {
  const tracks = await getAllTracks();
  const track = tracks.find((t) => t.id === trackId);
  if (!track) return null;

  const cleanDest = destinationFolder.trim() || 'Root';
  const updatedTrack: AudioTrack = {
    ...track,
    folder: cleanDest,
    path: cleanDest === 'Root' ? track.name : `${cleanDest}/${track.name}`,
  };

  await updateTrack(updatedTrack);
  return updatedTrack;
}

export async function copyTrack(trackId: string, destinationFolder: string): Promise<AudioTrack | null> {
  const tracks = await getAllTracks();
  const track = tracks.find((t) => t.id === trackId);
  if (!track) return null;

  const blob = await getAudioBlob(trackId);
  if (!blob) return null;

  const cleanDest = destinationFolder.trim() || 'Root';
  const newId = 'track_' + Math.random().toString(36).substring(2, 10) + '_' + Date.now().toString(36);
  const newTrack: AudioTrack = {
    ...track,
    id: newId,
    folder: cleanDest,
    path: cleanDest === 'Root' ? track.name : `${cleanDest}/${track.name}`,
    title: `${track.title} (Copy)`,
    name: `${track.title} (Copy).${track.name.split('.').pop() || 'mp3'}`,
    dateAdded: Date.now(),
    playCount: 0,
    lastPlayed: undefined,
  };

  await addTracksWithBlobs([{ track: newTrack, blob }]);
  return newTrack;
}

export async function batchDeleteTracks(trackIds: string[]): Promise<number> {
  if (trackIds.length === 0) return 0;
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([TRACKS_STORE, BLOBS_STORE], 'readwrite');
    const trackStore = tx.objectStore(TRACKS_STORE);
    const blobStore = tx.objectStore(BLOBS_STORE);

    trackIds.forEach((id) => {
      trackStore.delete(id);
      blobStore.delete(id);
    });

    tx.oncomplete = () => resolve(trackIds.length);
    tx.onerror = () => reject(tx.error);
  });
}

export async function batchMoveTracks(trackIds: string[], destinationFolder: string): Promise<number> {
  if (trackIds.length === 0) return 0;
  const cleanDest = destinationFolder.trim() || 'Root';
  const tracks = await getAllTracks();
  const idSet = new Set(trackIds);
  const toUpdate = tracks.filter((t) => idSet.has(t.id));

  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(TRACKS_STORE, 'readwrite');
    const store = tx.objectStore(TRACKS_STORE);

    toUpdate.forEach((t) => {
      const updated: AudioTrack = {
        ...t,
        folder: cleanDest,
        path: cleanDest === 'Root' ? t.name : `${cleanDest}/${t.name}`,
      };
      store.put(updated);
    });

    tx.oncomplete = () => resolve(toUpdate.length);
    tx.onerror = () => reject(tx.error);
  });
}

export async function batchCopyTracks(trackIds: string[], destinationFolder: string): Promise<number> {
  if (trackIds.length === 0) return 0;
  const cleanDest = destinationFolder.trim() || 'Root';
  const tracks = await getAllTracks();
  const idSet = new Set(trackIds);
  const toCopy = tracks.filter((t) => idSet.has(t.id));

  const newItems: { track: AudioTrack; blob: Blob }[] = [];

  for (const t of toCopy) {
    const blob = await getAudioBlob(t.id);
    if (blob) {
      const newId = 'track_' + Math.random().toString(36).substring(2, 10) + '_' + Date.now().toString(36);
      const newTrack: AudioTrack = {
        ...t,
        id: newId,
        folder: cleanDest,
        path: cleanDest === 'Root' ? t.name : `${cleanDest}/${t.name}`,
        title: `${t.title} (Copy)`,
        name: `${t.title} (Copy).${t.name.split('.').pop() || 'mp3'}`,
        dateAdded: Date.now(),
        playCount: 0,
        lastPlayed: undefined,
      };
      newItems.push({ track: newTrack, blob });
    }
  }

  await addTracksWithBlobs(newItems);
  return newItems.length;
}

export async function saveTrackSubtitles(
  trackId: string,
  subtitles: { start: number; end: number; text: string }[],
  source: 'offline' | 'ai' | 'file' = 'offline'
): Promise<void> {
  const tracks = await getAllTracks();
  const track = tracks.find((t) => t.id === trackId);
  if (!track) return;

  const updated: AudioTrack = {
    ...track,
    subtitles,
    subtitleSource: source,
  };

  await updateTrack(updated);
}

export async function clearAllVault(): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([TRACKS_STORE, BLOBS_STORE], 'readwrite');
    tx.objectStore(TRACKS_STORE).clear();
    tx.objectStore(BLOBS_STORE).clear();
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getStorageEstimate(): Promise<{
  usedBytes: number;
  quotaBytes: number;
  percentUsed: number;
  trackCount: number;
}> {
  let usedBytes = 0;
  let quotaBytes = 0;

  if (navigator.storage && navigator.storage.estimate) {
    try {
      const estimate = await navigator.storage.estimate();
      usedBytes = estimate.usage || 0;
      quotaBytes = estimate.quota || 0;
    } catch {
      // Fallback
    }
  }

  const tracks = await getAllTracks();
  const calculatedSize = tracks.reduce((sum, t) => sum + (t.size || 0), 0);
  if (usedBytes === 0) usedBytes = calculatedSize;

  const percentUsed = quotaBytes > 0 ? (usedBytes / quotaBytes) * 100 : 0;

  return {
    usedBytes,
    quotaBytes,
    percentUsed: Math.min(100, Math.round(percentUsed * 10) / 10),
    trackCount: tracks.length,
  };
}

/**
 * Generates an audio WAV file programmatically via Web Audio API
 * Used to populate sample demo recordings so the user can test all features right away
 */
export async function createSyntheticWav(
  durationSec: number = 5,
  frequency: number = 440,
  type: 'sine' | 'voice-note' | 'chime' = 'voice-note'
): Promise<Blob> {
  const sampleRate = 22050;
  const numChannels = 1;
  const numSamples = Math.floor(sampleRate * durationSec);
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  // Helper to write string to DataView
  const writeString = (offset: number, str: string) => {
    for (let i = 0; i < str.length; i++) {
      view.setUint8(offset + i, str.charCodeAt(i));
    }
  };

  // RIFF chunk descriptor
  writeString(0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeString(8, 'WAVE');

  // "fmt " sub-chunk
  writeString(12, 'fmt ');
  view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
  view.setUint16(20, 1, true); // AudioFormat (1 for PCM)
  view.setUint16(22, numChannels, true); // NumChannels
  view.setUint32(24, sampleRate, true); // SampleRate
  view.setUint32(28, sampleRate * numChannels * 2, true); // ByteRate
  view.setUint16(32, numChannels * 2, true); // BlockAlign
  view.setUint16(34, 16, true); // BitsPerSample

  // "data" sub-chunk
  writeString(36, 'data');
  view.setUint32(40, numSamples * 2, true);

  // Synthesize sample data
  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let sample = 0;

    if (type === 'voice-note') {
      // Voice-like harmonic formants + tremolo modulation
      const fundamental = frequency;
      const formant1 = Math.sin(2 * Math.PI * fundamental * t);
      const formant2 = 0.5 * Math.sin(2 * Math.PI * (fundamental * 2.1) * t);
      const formant3 = 0.25 * Math.sin(2 * Math.PI * (fundamental * 3.4) * t);
      const speechRhythm = Math.sin(2 * Math.PI * 3.5 * t); // cadence
      const envelope = Math.sin((Math.PI * i) / numSamples); // fade in/out
      sample = (formant1 + formant2 + formant3) * 0.4 * (0.6 + 0.4 * speechRhythm) * envelope;
    } else if (type === 'chime') {
      // Pleasant melodic arpeggio
      const noteFreq = frequency * Math.pow(2, Math.floor((t * 2) % 4) * 0.25);
      const decay = Math.exp(-((t % 0.5) * 4));
      sample = Math.sin(2 * Math.PI * noteFreq * t) * decay * 0.5;
    } else {
      // Sine tone with subtle pulse
      sample = Math.sin(2 * Math.PI * frequency * t) * 0.5;
    }

    // Clamp and convert to 16-bit PCM
    const s = Math.max(-1, Math.min(1, sample));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    offset += 2;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

export async function createDemoVault(): Promise<AudioTrack[]> {
  const demoList = [
    {
      name: '01_Introduction_Lecture.wav',
      path: 'Lectures/Semester 1/01_Introduction_Lecture.wav',
      folder: 'Lectures/Semester 1',
      duration: 12,
      freq: 220,
      type: 'voice-note' as const,
    },
    {
      name: '02_Cell_Biology_Notes.wav',
      path: 'Lectures/Semester 1/02_Cell_Biology_Notes.wav',
      folder: 'Lectures/Semester 1',
      duration: 15,
      freq: 260,
      type: 'voice-note' as const,
    },
    {
      name: '03_Quantum_Physics_Intro.wav',
      path: 'Lectures/Physics/03_Quantum_Physics_Intro.wav',
      folder: 'Lectures/Physics',
      duration: 18,
      freq: 310,
      type: 'voice-note' as const,
    },
    {
      name: 'Meeting_Audio_Memo_Client_Review.wav',
      path: 'Work Memos/2024/Meeting_Audio_Memo_Client_Review.wav',
      folder: 'Work Memos/2024',
      duration: 14,
      freq: 190,
      type: 'voice-note' as const,
    },
    {
      name: 'Project_Discussion_Sprint_Planning.wav',
      path: 'Work Memos/2024/Project_Discussion_Sprint_Planning.wav',
      folder: 'Work Memos/2024',
      duration: 20,
      freq: 240,
      type: 'voice-note' as const,
    },
    {
      name: 'Focus_Ambient_Study_Chime.wav',
      path: 'Music & Ambience/Focus_Ambient_Study_Chime.wav',
      folder: 'Music & Ambience',
      duration: 16,
      freq: 440,
      type: 'chime' as const,
    },
    {
      name: 'Evening_Relaxation_Melody.wav',
      path: 'Music & Ambience/Evening_Relaxation_Melody.wav',
      folder: 'Music & Ambience',
      duration: 22,
      freq: 330,
      type: 'chime' as const,
    },
    {
      name: 'Quick_Voice_Reminder_Groceries.wav',
      path: 'Voice Memos/Quick_Voice_Reminder_Groceries.wav',
      folder: 'Voice Memos',
      duration: 8,
      freq: 280,
      type: 'voice-note' as const,
    },
  ];

  const items: { track: AudioTrack; blob: Blob }[] = [];

  for (const item of demoList) {
    const blob = await createSyntheticWav(item.duration, item.freq, item.type);
    const id = 'demo_' + Math.random().toString(36).substring(2, 9);
    const title = item.name.replace(/\.[^/.]+$/, '').replace(/_/g, ' ');

    let demoSubtitles: { start: number; end: number; text: string }[] | undefined = undefined;

    if (item.name.includes('Introduction_Lecture')) {
      demoSubtitles = [
        { start: 0.0, end: 3.5, text: "Welcome everyone to the introductory lecture series." },
        { start: 3.5, end: 7.2, text: "Today we will explore core principles and foundational concepts." },
        { start: 7.2, end: 11.8, text: "Please make sure to review the syllabus in your folder." },
      ];
    } else if (item.name.includes('Cell_Biology')) {
      demoSubtitles = [
        { start: 0.0, end: 4.0, text: "In this session, we investigate cell membranes and cellular transport." },
        { start: 4.0, end: 9.5, text: "Notice how passive diffusion differs significantly from active transport." },
        { start: 9.5, end: 14.8, text: "Mitochondria produce ATP, serving as the powerhouse of the cell." },
      ];
    } else if (item.name.includes('Physics')) {
      demoSubtitles = [
        { start: 0.0, end: 5.0, text: "Quantum mechanics describes the fundamental behavior of subatomic particles." },
        { start: 5.0, end: 11.0, text: "Wave-particle duality illustrates that photons exhibit both wave and particle traits." },
        { start: 11.0, end: 17.5, text: "Heisenberg's uncertainty principle sets a limit on simultaneous measurement precision." },
      ];
    } else if (item.name.includes('Meeting')) {
      demoSubtitles = [
        { start: 0.0, end: 4.2, text: "Reviewing the client feedback regarding the new audio vault release." },
        { start: 4.2, end: 9.0, text: "All recordings must remain strictly sandboxed in browser storage." },
        { start: 9.0, end: 13.5, text: "Action item: verify offline PWA shortcuts on both Android and iOS." },
      ];
    }

    const track: AudioTrack = {
      id,
      name: item.name,
      title,
      path: item.path,
      folder: item.folder,
      size: blob.size,
      type: 'audio/wav',
      duration: item.duration,
      dateAdded: Date.now() - Math.floor(Math.random() * 86400000 * 3),
      favorite: item.name.includes('Biology') || item.name.includes('Focus'),
      playCount: 0,
      lastPlayed: undefined,
      subtitles: demoSubtitles,
      subtitleSource: demoSubtitles ? 'offline' : undefined,
    };

    items.push({ track, blob });
  }

  await addTracksWithBlobs(items);
  return items.map((i) => i.track);
}
