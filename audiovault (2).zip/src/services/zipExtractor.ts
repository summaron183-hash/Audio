import JSZip from 'jszip';
import { AudioTrack } from '../types';
import { parseSrtOrVtt } from './subtitles';

export interface ExtractionProgress {
  stage: 'reading' | 'extracting' | 'saving' | 'complete' | 'error';
  totalFiles: number;
  extractedFiles: number;
  currentFileName: string;
  percentage: number;
  error?: string;
}

const AUDIO_EXTENSIONS = new Set([
  'mp3',
  'm4a',
  'wav',
  'ogg',
  'aac',
  'flac',
  'opus',
  'webm',
  'wma',
  'amr',
  '3gp',
  'mp4',
]);

export function isAudioFile(fileName: string): boolean {
  const ext = fileName.split('.').pop()?.toLowerCase();
  return ext ? AUDIO_EXTENSIONS.has(ext) : false;
}

function getMimeType(fileName: string): string {
  const ext = fileName.split('.').pop()?.toLowerCase();
  switch (ext) {
    case 'mp3':
      return 'audio/mpeg';
    case 'wav':
      return 'audio/wav';
    case 'm4a':
    case 'mp4':
    case 'aac':
      return 'audio/mp4';
    case 'ogg':
    case 'opus':
      return 'audio/ogg';
    case 'flac':
      return 'audio/flac';
    case 'webm':
      return 'audio/webm';
    case 'amr':
      return 'audio/amr';
    default:
      return 'audio/mpeg';
  }
}

function probeAudioDuration(blob: Blob): Promise<number> {
  return new Promise((resolve) => {
    try {
      const url = URL.createObjectURL(blob);
      const audio = new Audio();
      let cleaned = false;

      const cleanup = () => {
        if (!cleaned) {
          cleaned = true;
          URL.revokeObjectURL(url);
          audio.src = '';
        }
      };

      const timer = setTimeout(() => {
        cleanup();
        resolve(0); // If taking too long, resolve 0 and probe later during playback
      }, 1500);

      audio.onloadedmetadata = () => {
        clearTimeout(timer);
        const dur = audio.duration;
        cleanup();
        resolve(Number.isFinite(dur) ? Math.round(dur) : 0);
      };

      audio.onerror = () => {
        clearTimeout(timer);
        cleanup();
        resolve(0);
      };

      audio.src = url;
    } catch {
      resolve(0);
    }
  });
}

export async function extractZipArchive(
  file: File,
  onProgress: (progress: ExtractionProgress) => void
): Promise<{ track: AudioTrack; blob: Blob }[]> {
  onProgress({
    stage: 'reading',
    totalFiles: 0,
    extractedFiles: 0,
    currentFileName: file.name,
    percentage: 5,
  });

  const zip = new JSZip();
  let zipContent: JSZip;
  try {
    zipContent = await zip.loadAsync(file);
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : 'Invalid or corrupted ZIP file';
    onProgress({
      stage: 'error',
      totalFiles: 0,
      extractedFiles: 0,
      currentFileName: file.name,
      percentage: 0,
      error: errorMsg,
    });
    throw new Error(errorMsg);
  }

  // Find all audio entries
  const audioEntries: { path: string; entry: JSZip.JSZipObject }[] = [];
  zipContent.forEach((relativePath, entry) => {
    if (!entry.dir && isAudioFile(relativePath) && !relativePath.startsWith('__MACOSX/')) {
      audioEntries.push({ path: relativePath, entry });
    }
  });

  if (audioEntries.length === 0) {
    const noAudioErr = 'No audio recordings (.mp3, .wav, .m4a, .aac, .ogg, .flac) found in this ZIP archive.';
    onProgress({
      stage: 'error',
      totalFiles: 0,
      extractedFiles: 0,
      currentFileName: file.name,
      percentage: 0,
      error: noAudioErr,
    });
    throw new Error(noAudioErr);
  }

  const results: { track: AudioTrack; blob: Blob }[] = [];
  const total = audioEntries.length;

  for (let i = 0; i < audioEntries.length; i++) {
    const { path: rawPath, entry } = audioEntries[i];
    // Normalize path separators
    const normalizedPath = rawPath.replace(/\\/g, '/').replace(/^\/+/, '');
    const pathParts = normalizedPath.split('/');
    const fileName = pathParts.pop() || 'recording.mp3';
    const folder = pathParts.length > 0 ? pathParts.join('/') : 'Root';

    onProgress({
      stage: 'extracting',
      totalFiles: total,
      extractedFiles: i,
      currentFileName: fileName,
      percentage: Math.round(10 + (i / total) * 70),
    });

    const mime = getMimeType(fileName);
    const blob = await entry.async('blob');
    const typedBlob = new Blob([blob], { type: mime });

    // Duration probe (quick attempt)
    const duration = await probeAudioDuration(typedBlob);

    const title = fileName.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');

    // Check for companion subtitle file (.srt or .vtt) in ZIP
    const baseName = normalizedPath.replace(/\.[^/.]+$/, '');
    const srtEntry = zipContent.file(baseName + '.srt') || zipContent.file(baseName + '.vtt');
    let subtitles = undefined;
    if (srtEntry) {
      try {
        const srtText = await srtEntry.async('text');
        const parsed = parseSrtOrVtt(srtText);
        if (parsed.length > 0) {
          subtitles = parsed;
        }
      } catch {}
    }

    const track: AudioTrack = {
      id: 'track_' + Math.random().toString(36).substring(2, 10) + '_' + Date.now().toString(36),
      name: fileName,
      title,
      path: normalizedPath,
      folder,
      size: typedBlob.size,
      type: mime,
      duration,
      dateAdded: Date.now(),
      favorite: false,
      playCount: 0,
      subtitles,
      subtitleSource: subtitles ? 'offline' : undefined,
    };

    results.push({ track, blob: typedBlob });
  }

  onProgress({
    stage: 'saving',
    totalFiles: total,
    extractedFiles: total,
    currentFileName: 'Writing recordings to browser storage...',
    percentage: 90,
  });

  return results;
}

export async function processRawAudioFiles(
  files: FileList | File[],
  onProgress: (progress: ExtractionProgress) => void
): Promise<{ track: AudioTrack; blob: Blob }[]> {
  const fileArray = Array.from(files).filter((f) => isAudioFile(f.name));
  const total = fileArray.length;

  if (total === 0) {
    throw new Error('No valid audio files selected.');
  }

  const results: { track: AudioTrack; blob: Blob }[] = [];

  for (let i = 0; i < fileArray.length; i++) {
    const file = fileArray[i];
    // If it comes from folder upload, webkitRelativePath might exist
    const relPath = (file as { webkitRelativePath?: string }).webkitRelativePath || file.name;
    const normalizedPath = relPath.replace(/\\/g, '/').replace(/^\/+/, '');
    const pathParts = normalizedPath.split('/');
    const fileName = pathParts.pop() || file.name;
    const folder = pathParts.length > 0 ? pathParts.join('/') : 'Uploaded Audio';

    onProgress({
      stage: 'extracting',
      totalFiles: total,
      extractedFiles: i,
      currentFileName: fileName,
      percentage: Math.round((i / total) * 80),
    });

    const duration = await probeAudioDuration(file);
    const title = fileName.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');

    const track: AudioTrack = {
      id: 'track_' + Math.random().toString(36).substring(2, 10) + '_' + Date.now().toString(36),
      name: fileName,
      title,
      path: normalizedPath,
      folder,
      size: file.size,
      type: file.type || getMimeType(fileName),
      duration,
      dateAdded: Date.now(),
      favorite: false,
      playCount: 0,
    };

    results.push({ track, blob: file });
  }

  return results;
}
