import React, { useState, useMemo } from 'react';
import {
  Folder,
  FolderOpen,
  FolderPlus,
  ChevronRight,
  Music,
  Play,
  Pause,
  Heart,
  Download,
  Trash2,
  Clock,
  Shuffle,
  Edit2,
  Copy,
  MoveRight,
  MoreVertical,
  X,
  Check,
  Subtitles,
} from 'lucide-react';
import { AudioTrack } from '../types';
import { usePlayer } from '../context/PlayerContext';
import { getAudioBlob } from '../services/storage';

interface FolderExplorerProps {
  tracks: AudioTrack[];
  currentFolderPath: string;
  onNavigateFolder: (path: string) => void;
  onToggleFavorite: (trackId: string) => void;
  onDeleteTrack: (trackId: string) => void;
  onDeleteFolder: (folderPath: string) => void;
  onRenameTrack: (trackId: string, newTitle: string) => Promise<void>;
  onRenameFolder: (oldFolder: string, newFolder: string) => Promise<void>;
  onMoveTrack: (trackId: string, targetFolder: string) => Promise<void>;
  onCopyTrack: (trackId: string, targetFolder: string) => Promise<void>;
  onCreateFolder: (newFolderPath: string) => void;
  allFolderPaths: string[];
}

function formatDuration(sec: number): string {
  if (!sec || !Number.isFinite(sec)) return '--:--';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function formatBytes(bytes: number): string {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export const FolderExplorer: React.FC<FolderExplorerProps> = ({
  tracks,
  currentFolderPath,
  onNavigateFolder,
  onToggleFavorite,
  onDeleteTrack,
  onDeleteFolder,
  onRenameTrack,
  onRenameFolder,
  onMoveTrack,
  onCopyTrack,
  onCreateFolder,
  allFolderPaths,
}) => {
  const { currentTrack, isPlaying, playTrack, togglePlayPause, setIsExpanded } = usePlayer();
  const [filterText, setFilterText] = useState('');

  // Modals state
  const [newFolderModalOpen, setNewFolderModalOpen] = useState(false);
  const [newFolderNameInput, setNewFolderNameInput] = useState('');

  const [renameFolderModalOpen, setRenameFolderModalOpen] = useState(false);
  const [folderToRename, setFolderToRename] = useState<string | null>(null);
  const [renameFolderInput, setRenameFolderInput] = useState('');

  const [renameTrackModalOpen, setRenameTrackModalOpen] = useState(false);
  const [trackToRename, setTrackToRename] = useState<AudioTrack | null>(null);
  const [renameTrackInput, setRenameTrackInput] = useState('');

  const [moveCopyModalOpen, setMoveCopyModalOpen] = useState(false);
  const [moveCopyAction, setMoveCopyAction] = useState<'move' | 'copy'>('move');
  const [trackToMoveCopy, setTrackToMoveCopy] = useState<AudioTrack | null>(null);
  const [targetFolderSelect, setTargetFolderSelect] = useState<string>('Root');
  const [customTargetFolder, setCustomTargetFolder] = useState('');

  // Track action menu dropdown state
  const [activeMenuTrackId, setActiveMenuTrackId] = useState<string | null>(null);

  // Breadcrumbs
  const breadcrumbs = useMemo(() => {
    if (!currentFolderPath || currentFolderPath === 'Root') {
      return [{ name: 'Root', path: 'Root' }];
    }
    const parts = currentFolderPath.split('/');
    const crumbs = [{ name: 'Home (Root)', path: 'Root' }];
    let accum = '';
    for (const part of parts) {
      accum = accum ? `${accum}/${part}` : part;
      crumbs.push({ name: part, path: accum });
    }
    return crumbs;
  }, [currentFolderPath]);

  // Determine subfolders and immediate tracks in this folder
  const { subfolders, currentTracks } = useMemo(() => {
    const isRoot = !currentFolderPath || currentFolderPath === 'Root';
    const subfolderMap = new Map<string, { count: number; totalSize: number }>();
    const immediateTracks: AudioTrack[] = [];

    // Also include created empty folders that match
    allFolderPaths.forEach((f) => {
      if (isRoot) {
        if (f !== 'Root') {
          const topLevel = f.split('/')[0];
          if (!subfolderMap.has(topLevel)) {
            subfolderMap.set(topLevel, { count: 0, totalSize: 0 });
          }
        }
      } else {
        if (f.startsWith(currentFolderPath + '/')) {
          const remainder = f.slice(currentFolderPath.length + 1);
          const nextSegment = remainder.split('/')[0];
          const subPath = `${currentFolderPath}/${nextSegment}`;
          if (!subfolderMap.has(subPath)) {
            subfolderMap.set(subPath, { count: 0, totalSize: 0 });
          }
        }
      }
    });

    tracks.forEach((track) => {
      const trackFolder = track.folder || 'Root';

      if (isRoot) {
        if (trackFolder === 'Root') {
          immediateTracks.push(track);
        } else {
          const topLevel = trackFolder.split('/')[0];
          const curr = subfolderMap.get(topLevel) || { count: 0, totalSize: 0 };
          curr.count += 1;
          curr.totalSize += track.size || 0;
          subfolderMap.set(topLevel, curr);
        }
      } else {
        if (trackFolder === currentFolderPath) {
          immediateTracks.push(track);
        } else if (trackFolder.startsWith(currentFolderPath + '/')) {
          const remainder = trackFolder.slice(currentFolderPath.length + 1);
          const nextSegment = remainder.split('/')[0];
          const subPath = `${currentFolderPath}/${nextSegment}`;
          const curr = subfolderMap.get(subPath) || { count: 0, totalSize: 0 };
          curr.count += 1;
          curr.totalSize += track.size || 0;
          subfolderMap.set(subPath, curr);
        }
      }
    });

    const folderList = Array.from(subfolderMap.entries()).map(([path, data]) => {
      const parts = path.split('/');
      return {
        path,
        name: parts[parts.length - 1],
        count: data.count,
        totalSize: data.totalSize,
      };
    });

    return {
      subfolders: folderList.sort((a, b) => a.name.localeCompare(b.name)),
      currentTracks: immediateTracks.sort((a, b) => a.name.localeCompare(b.name)),
    };
  }, [tracks, currentFolderPath, allFolderPaths]);

  // Filter within folder
  const filteredTracks = useMemo(() => {
    if (!filterText.trim()) return currentTracks;
    const q = filterText.toLowerCase();
    return currentTracks.filter(
      (t) => t.title.toLowerCase().includes(q) || t.name.toLowerCase().includes(q)
    );
  }, [currentTracks, filterText]);

  const handleDownload = async (track: AudioTrack) => {
    const blob = await getAudioBlob(track.id);
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = track.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const handlePlayAll = (shuffle = false) => {
    if (filteredTracks.length === 0) return;
    let list = [...filteredTracks];
    if (shuffle) {
      list = list.sort(() => Math.random() - 0.5);
    }
    playTrack(list[0], list);
  };

  const submitCreateFolder = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newFolderNameInput.trim();
    if (!name) return;

    const fullPath =
      !currentFolderPath || currentFolderPath === 'Root'
        ? name
        : `${currentFolderPath}/${name}`;

    onCreateFolder(fullPath);
    setNewFolderNameInput('');
    setNewFolderModalOpen(false);
  };

  const submitRenameFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!folderToRename || !renameFolderInput.trim()) return;

    const parts = folderToRename.split('/');
    parts[parts.length - 1] = renameFolderInput.trim();
    const newFullPath = parts.join('/');

    await onRenameFolder(folderToRename, newFullPath);
    setRenameFolderModalOpen(false);
    setFolderToRename(null);
  };

  const submitRenameTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackToRename || !renameTrackInput.trim()) return;

    await onRenameTrack(trackToRename.id, renameTrackInput.trim());
    setRenameTrackModalOpen(false);
    setTrackToRename(null);
  };

  const submitMoveCopy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackToMoveCopy) return;

    const dest = customTargetFolder.trim() || targetFolderSelect;
    if (moveCopyAction === 'move') {
      await onMoveTrack(trackToMoveCopy.id, dest);
    } else {
      await onCopyTrack(trackToMoveCopy.id, dest);
    }
    setMoveCopyModalOpen(false);
    setTrackToMoveCopy(null);
  };

  return (
    <div className="space-y-6">
      {/* Breadcrumb Header Bar & Action Buttons */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-md shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5 text-sm text-slate-400">
            <FolderOpen className="w-4 h-4 text-cyan-400 mr-1" />
            {breadcrumbs.map((crumb, idx) => {
              const isLast = idx === breadcrumbs.length - 1;
              return (
                <React.Fragment key={crumb.path}>
                  {idx > 0 && <ChevronRight className="w-3.5 h-3.5 text-slate-600" />}
                  <button
                    onClick={() => onNavigateFolder(crumb.path)}
                    className={`px-2.5 py-1 rounded-lg transition font-medium text-xs sm:text-sm ${
                      isLast
                        ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                        : 'hover:bg-slate-800 text-slate-300 hover:text-white'
                    }`}
                  >
                    {crumb.name}
                  </button>
                </React.Fragment>
              );
            })}
          </div>

          {/* New Folder Button */}
          <button
            onClick={() => setNewFolderModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 text-xs font-semibold transition"
          >
            <FolderPlus className="w-4 h-4" />
            <span>New Folder</span>
          </button>
        </div>

        {/* Action Controls & Folder Stats */}
        <div className="mt-4 pt-3 border-t border-slate-800/70 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span>{subfolders.length} subfolders</span>
            <span>•</span>
            <span>{currentTracks.length} recordings in this directory</span>
          </div>

          <div className="flex items-center gap-2">
            {currentTracks.length > 0 && (
              <>
                <button
                  onClick={() => handlePlayAll(false)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-semibold text-xs transition shadow-sm"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Play All
                </button>
                <button
                  onClick={() => handlePlayAll(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition border border-slate-700"
                  title="Shuffle play folder"
                >
                  <Shuffle className="w-3.5 h-3.5" />
                  Shuffle
                </button>
              </>
            )}

            {currentFolderPath && currentFolderPath !== 'Root' && (
              <button
                onClick={() => {
                  setFolderToRename(currentFolderPath);
                  const parts = currentFolderPath.split('/');
                  setRenameFolderInput(parts[parts.length - 1]);
                  setRenameFolderModalOpen(true);
                }}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs border border-slate-700 transition"
                title="Rename this folder"
              >
                <Edit2 className="w-3 h-3 text-cyan-400" />
                <span>Rename Folder</span>
              </button>
            )}

            {currentFolderPath && currentFolderPath !== 'Root' && (
              <button
                onClick={() => onDeleteFolder(currentFolderPath)}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 text-xs border border-rose-500/30 transition"
                title="Delete this folder and its recordings"
              >
                <Trash2 className="w-3 h-3" />
                <span>Delete Folder</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Subfolders Grid with Folder Rename and Delete Options */}
      {subfolders.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3 px-1">
            Subfolders ({subfolders.length})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {subfolders.map((folder) => (
              <div
                key={folder.path}
                className="group relative flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 transition shadow-sm"
              >
                {/* Clickable folder zone */}
                <div
                  onClick={() => onNavigateFolder(folder.path)}
                  className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 group-hover:bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/20 transition">
                    <Folder className="w-5 h-5 fill-amber-400/20" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-slate-200 group-hover:text-cyan-300 truncate transition">
                      {folder.name}
                    </p>
                    <p className="text-xs text-slate-400">
                      {folder.count} {folder.count === 1 ? 'audio' : 'audios'} • {formatBytes(folder.totalSize)}
                    </p>
                  </div>
                </div>

                {/* Subfolder action icons: Rename & Delete */}
                <div className="flex items-center gap-1 shrink-0 ml-2 opacity-80 group-hover:opacity-100 transition">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setFolderToRename(folder.path);
                      setRenameFolderInput(folder.name);
                      setRenameFolderModalOpen(true);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-700/60 transition"
                    title="Rename folder"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteFolder(folder.path);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-700/60 transition"
                    title="Delete folder and files"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Audio Recordings in This Folder */}
      <div>
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Recordings ({currentTracks.length})
          </h3>

          {currentTracks.length > 5 && (
            <input
              type="text"
              placeholder="Filter current folder..."
              value={filterText}
              onChange={(e) => setFilterText(e.target.value)}
              className="text-xs bg-slate-900/80 border border-slate-700/80 rounded-lg px-2.5 py-1 text-slate-200 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          )}
        </div>

        {filteredTracks.length === 0 ? (
          <div className="bg-slate-900/40 border border-slate-800/60 rounded-2xl p-8 text-center">
            <Music className="w-10 h-10 text-slate-600 mx-auto mb-2" />
            <p className="text-sm text-slate-400">
              {subfolders.length > 0
                ? 'No loose audio files in this directory. Click a subfolder above to view files.'
                : 'No recordings in this folder.'}
            </p>
          </div>
        ) : (
          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl divide-y divide-slate-800/50 overflow-visible shadow-sm">
            {filteredTracks.map((track) => {
              const isCurrent = currentTrack?.id === track.id;
              const isCurrentlyPlaying = isCurrent && isPlaying;
              const hasSubtitles = track.subtitles && track.subtitles.length > 0;

              return (
                <div
                  key={track.id}
                  className={`group flex items-center justify-between p-3 sm:px-4 transition relative ${
                    isCurrent
                      ? 'bg-gradient-to-r from-cyan-950/50 via-slate-900 to-indigo-950/40 border-l-4 border-l-cyan-400'
                      : 'hover:bg-slate-800/40'
                  }`}
                >
                  {/* Left: Play button & info */}
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <button
                      onClick={() => {
                        if (isCurrent) {
                          togglePlayPause();
                        } else {
                          playTrack(track, filteredTracks);
                        }
                      }}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition ${
                        isCurrentlyPlaying
                          ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25 ring-2 ring-cyan-400/40'
                          : 'bg-slate-800 text-slate-300 hover:bg-cyan-500 hover:text-slate-950 border border-slate-700/70'
                      }`}
                      title={isCurrentlyPlaying ? 'Pause' : 'Play'}
                    >
                      {isCurrentlyPlaying ? (
                        <Pause className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <p
                          onClick={() => {
                            if (!isCurrent) playTrack(track, filteredTracks);
                            setIsExpanded(true);
                          }}
                          className={`text-sm font-medium truncate cursor-pointer hover:underline ${
                            isCurrent ? 'text-cyan-300 font-semibold' : 'text-slate-200'
                          }`}
                        >
                          {track.title}
                        </p>
                        {hasSubtitles && (
                          <span
                            className="px-1.5 py-0.2 rounded text-[9px] font-mono font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 shrink-0"
                            title="English Subtitles Available"
                          >
                            CC
                          </span>
                        )}
                        {isCurrentlyPlaying && (
                          <span className="flex items-center gap-0.5 shrink-0">
                            <span className="w-1 h-3 bg-cyan-400 animate-pulse rounded-full" />
                            <span className="w-1 h-4 bg-cyan-400 animate-pulse delay-75 rounded-full" />
                            <span className="w-1 h-2 bg-cyan-400 animate-pulse delay-150 rounded-full" />
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                        <span className="uppercase text-[10px] font-mono font-medium px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          {track.name.split('.').pop() || 'AUDIO'}
                        </span>
                        <span>•</span>
                        <span>{formatBytes(track.size)}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatDuration(track.duration)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Actions: Favorite, Rename, Move, Copy, Download, Delete */}
                  <div className="flex items-center gap-1 ml-2 shrink-0">
                    <button
                      onClick={() => onToggleFavorite(track.id)}
                      className={`p-2 rounded-lg transition ${
                        track.favorite
                          ? 'text-rose-500 hover:text-rose-400'
                          : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'
                      }`}
                      title={track.favorite ? 'Remove from favorites' : 'Add to favorites'}
                    >
                      <Heart className={`w-4 h-4 ${track.favorite ? 'fill-current' : ''}`} />
                    </button>

                    {/* Rename file */}
                    <button
                      onClick={() => {
                        setTrackToRename(track);
                        setRenameTrackInput(track.title);
                        setRenameTrackModalOpen(true);
                      }}
                      className="p-2 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800 transition"
                      title="Rename recording"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    {/* Move file */}
                    <button
                      onClick={() => {
                        setTrackToMoveCopy(track);
                        setMoveCopyAction('move');
                        setTargetFolderSelect('Root');
                        setCustomTargetFolder('');
                        setMoveCopyModalOpen(true);
                      }}
                      className="p-2 rounded-lg text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition hidden sm:inline-flex"
                      title="Move recording to another folder"
                    >
                      <MoveRight className="w-4 h-4" />
                    </button>

                    {/* Copy file */}
                    <button
                      onClick={() => {
                        setTrackToMoveCopy(track);
                        setMoveCopyAction('copy');
                        setTargetFolderSelect(track.folder || 'Root');
                        setCustomTargetFolder('');
                        setMoveCopyModalOpen(true);
                      }}
                      className="p-2 rounded-lg text-slate-400 hover:text-indigo-300 hover:bg-slate-800 transition hidden sm:inline-flex"
                      title="Copy recording to another folder"
                    >
                      <Copy className="w-4 h-4" />
                    </button>

                    {/* Download */}
                    <button
                      onClick={() => handleDownload(track)}
                      className="p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition"
                      title="Download audio recording"
                    >
                      <Download className="w-4 h-4" />
                    </button>

                    {/* Delete file */}
                    <button
                      onClick={() => onDeleteTrack(track.id)}
                      className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                      title="Delete recording from vault"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* CREATE FOLDER MODAL */}
      {newFolderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-2">
              <FolderPlus className="w-5 h-5 text-cyan-400" />
              <span>Create New Folder</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Enter the folder name. It will be created in{' '}
              <strong className="text-cyan-300">{currentFolderPath || 'Root'}</strong>.
            </p>
            <form onSubmit={submitCreateFolder} className="space-y-4">
              <input
                type="text"
                autoFocus
                placeholder="e.g. Biology Semester 2, Voice Memos 2025"
                value={newFolderNameInput}
                onChange={(e) => setNewFolderNameInput(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setNewFolderModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                >
                  Create Folder
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RENAME FOLDER MODAL */}
      {renameFolderModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-2">
              <Edit2 className="w-5 h-5 text-cyan-400" />
              <span>Rename Folder</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Renaming "{folderToRename}" will update all recordings inside this directory.
            </p>
            <form onSubmit={submitRenameFolder} className="space-y-4">
              <input
                type="text"
                autoFocus
                value={renameFolderInput}
                onChange={(e) => setRenameFolderInput(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRenameFolderModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RENAME RECORDING MODAL */}
      {renameTrackModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-2">
              <Edit2 className="w-5 h-5 text-cyan-400" />
              <span>Rename Recording</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Update the recording title and display name.
            </p>
            <form onSubmit={submitRenameTrack} className="space-y-4">
              <input
                type="text"
                autoFocus
                value={renameTrackInput}
                onChange={(e) => setRenameTrackInput(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-cyan-400"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRenameTrackModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
                >
                  Rename
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MOVE OR COPY RECORDING MODAL */}
      {moveCopyModalOpen && trackToMoveCopy && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-2">
              {moveCopyAction === 'move' ? (
                <MoveRight className="w-5 h-5 text-amber-400" />
              ) : (
                <Copy className="w-5 h-5 text-indigo-400" />
              )}
              <span className="capitalize">{moveCopyAction} Recording</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4 truncate">
              {trackToMoveCopy.title}
            </p>
            <form onSubmit={submitMoveCopy} className="space-y-4">
              <div>
                <label className="block text-xs text-slate-300 mb-1.5 font-medium">
                  Select Existing Destination Folder:
                </label>
                <select
                  value={targetFolderSelect}
                  onChange={(e) => setTargetFolderSelect(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-200 focus:outline-none focus:border-cyan-400"
                >
                  <option value="Root">Root (Home Directory)</option>
                  {allFolderPaths
                    .filter((f) => f && f !== 'Root')
                    .map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1.5 font-medium">
                  Or Type a New Target Folder Path:
                </label>
                <input
                  type="text"
                  placeholder="e.g. Lectures/2025/Chemistry"
                  value={customTargetFolder}
                  onChange={(e) => setCustomTargetFolder(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setMoveCopyModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs capitalize"
                >
                  Confirm {moveCopyAction}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
