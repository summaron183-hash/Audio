import React, { useState, useMemo } from 'react';
import {
  Music,
  Play,
  Pause,
  Heart,
  Clock,
  Folder,
  Download,
  Trash2,
  Shuffle,
  CheckSquare,
  Square,
  Check,
  MoveRight,
  Copy,
  X,
  Sparkles,
} from 'lucide-react';
import { AudioTrack } from '../types';
import { usePlayer } from '../context/PlayerContext';
import { getAudioBlob } from '../services/storage';

interface AllTracksViewProps {
  tracks: AudioTrack[];
  onToggleFavorite: (trackId: string) => void;
  onDeleteTrack: (trackId: string) => void;
  onNavigateFolder?: (folderPath: string) => void;
  onBatchDelete?: (trackIds: string[]) => Promise<void>;
  onBatchMove?: (trackIds: string[], targetFolder: string) => Promise<void>;
  onBatchCopy?: (trackIds: string[], targetFolder: string) => Promise<void>;
  allFolderPaths?: string[];
  title?: string;
  emptyMessage?: string;
}

type SortField = 'name' | 'dateAdded' | 'duration' | 'size' | 'playCount';
type SortDirection = 'asc' | 'desc';

function formatDuration(sec: number): string {
  if (!sec || !Number.isFinite(sec)) return '--:--';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

function formatBytes(bytes: number): string {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export const AllTracksView: React.FC<AllTracksViewProps> = ({
  tracks,
  onToggleFavorite,
  onDeleteTrack,
  onNavigateFolder,
  onBatchDelete,
  onBatchMove,
  onBatchCopy,
  allFolderPaths = [],
  title = 'All Recordings',
  emptyMessage = 'No audio recordings found in this view.',
}) => {
  const { currentTrack, isPlaying, playTrack, togglePlayPause, setIsExpanded } = usePlayer();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [visibleCount, setVisibleCount] = useState(60);

  // Batch Selection State
  const [isBatchMode, setIsBatchMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Batch Move/Copy Modal State
  const [batchActionModalOpen, setBatchActionModalOpen] = useState(false);
  const [batchActionType, setBatchActionType] = useState<'move' | 'copy'>('move');
  const [targetFolderSelect, setTargetFolderSelect] = useState('Root');
  const [customTargetFolder, setCustomTargetFolder] = useState('');
  const [isProcessingBatch, setIsProcessingBatch] = useState(false);
  const [batchDeleteModalOpen, setBatchDeleteModalOpen] = useState(false);

  // Filter & Sort
  const processedTracks = useMemo(() => {
    let result = [...tracks];

    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      result = result.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.name.toLowerCase().includes(q) ||
          t.folder.toLowerCase().includes(q)
      );
    }

    result.sort((a, b) => {
      let cmp = 0;
      switch (sortField) {
        case 'name':
          cmp = a.name.localeCompare(b.name);
          break;
        case 'dateAdded':
          cmp = (a.dateAdded || 0) - (b.dateAdded || 0);
          break;
        case 'duration':
          cmp = (a.duration || 0) - (b.duration || 0);
          break;
        case 'size':
          cmp = (a.size || 0) - (b.size || 0);
          break;
        case 'playCount':
          cmp = (a.playCount || 0) - (b.playCount || 0);
          break;
      }
      return sortDirection === 'asc' ? cmp : -cmp;
    });

    return result;
  }, [tracks, searchTerm, sortField, sortDirection]);

  const visibleTracks = useMemo(() => {
    return processedTracks.slice(0, visibleCount);
  }, [processedTracks, visibleCount]);

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleDownload = async (track: AudioTrack) => {
    const blob = await getAudioBlob(track.id);
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = track.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  const handlePlayAll = (shuffle = false) => {
    if (processedTracks.length === 0) return;
    let list = [...processedTracks];
    if (shuffle) {
      list = list.sort(() => Math.random() - 0.5);
    }
    playTrack(list[0], list);
  };

  // Batch Selection Handlers
  const toggleSelectTrack = (trackId: string) => {
    setSelectedIds((prev) => {
      const updated = new Set(prev);
      if (updated.has(trackId)) {
        updated.delete(trackId);
      } else {
        updated.add(trackId);
      }
      return updated;
    });
  };

  const handleSelectAll = () => {
    if (selectedIds.size === processedTracks.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(processedTracks.map((t) => t.id)));
    }
  };

  const handleExecuteBatchDelete = async () => {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;

    setIsProcessingBatch(true);
    if (onBatchDelete) {
      await onBatchDelete(ids);
    } else {
      for (const id of ids) {
        await onDeleteTrack(id);
      }
    }
    setSelectedIds(new Set());
    setIsBatchMode(false);
    setIsProcessingBatch(false);
    setBatchDeleteModalOpen(false);
  };

  const handleOpenBatchMoveCopy = (type: 'move' | 'copy') => {
    if (selectedIds.size === 0) return;
    setBatchActionType(type);
    setTargetFolderSelect('Root');
    setCustomTargetFolder('');
    setBatchActionModalOpen(true);
  };

  const submitBatchMoveCopy = async (e: React.FormEvent) => {
    e.preventDefault();
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;

    const dest = customTargetFolder.trim() || targetFolderSelect;
    setIsProcessingBatch(true);

    if (batchActionType === 'move') {
      if (onBatchMove) {
        await onBatchMove(ids, dest);
      }
    } else {
      if (onBatchCopy) {
        await onBatchCopy(ids, dest);
      }
    }

    setIsProcessingBatch(false);
    setBatchActionModalOpen(false);
    setSelectedIds(new Set());
    setIsBatchMode(false);
  };

  return (
    <div className="space-y-4">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900/60 border border-slate-800 p-4 rounded-2xl">
        <div>
          <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
            <span>{title}</span>
            <span className="text-xs font-mono font-medium px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {processedTracks.length}
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Offline IndexedDB recordings list
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {processedTracks.length > 0 && !isBatchMode && (
            <>
              <button
                onClick={() => handlePlayAll(false)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                Play All
              </button>
              <button
                onClick={() => handlePlayAll(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition border border-slate-700"
              >
                <Shuffle className="w-3.5 h-3.5" />
                Shuffle
              </button>
            </>
          )}

          {/* Toggle Batch Selection Mode Button */}
          {processedTracks.length > 0 && (
            <button
              onClick={() => {
                setIsBatchMode(!isBatchMode);
                if (isBatchMode) setSelectedIds(new Set());
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition ${
                isBatchMode
                  ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-bold shadow-md shadow-cyan-500/20'
                  : 'bg-slate-800/90 text-cyan-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              <CheckSquare className="w-3.5 h-3.5" />
              <span>{isBatchMode ? 'Cancel Selection' : 'Batch Selection'}</span>
            </button>
          )}

          {/* Sort Menu */}
          {!isBatchMode && (
            <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-xl border border-slate-700">
              <button
                onClick={() => toggleSort('name')}
                className={`px-2 py-1 rounded-lg text-xs font-medium transition ${
                  sortField === 'name' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300'
                }`}
                title="Sort by Name"
              >
                Name {sortField === 'name' ? (sortDirection === 'asc' ? '↑' : '↓') : ''}
              </button>
              <button
                onClick={() => toggleSort('dateAdded')}
                className={`px-2 py-1 rounded-lg text-xs font-medium transition ${
                  sortField === 'dateAdded' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300'
                }`}
                title="Sort by Date Added"
              >
                Date {sortField === 'dateAdded' ? (sortDirection === 'asc' ? '↑' : '↓') : ''}
              </button>
              <button
                onClick={() => toggleSort('duration')}
                className={`px-2 py-1 rounded-lg text-xs font-medium transition ${
                  sortField === 'duration' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-300'
                }`}
                title="Sort by Duration"
              >
                Length {sortField === 'duration' ? (sortDirection === 'asc' ? '↑' : '↓') : ''}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Floating / Sticky Batch Actions Toolbar when Batch Mode is Active */}
      {isBatchMode && (
        <div className="sticky top-20 z-20 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border-2 border-cyan-400/80 rounded-2xl p-3 sm:px-5 shadow-2xl flex flex-wrap items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-3">
            <button
              onClick={handleSelectAll}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 border border-slate-700 font-medium transition"
            >
              {selectedIds.size === processedTracks.length ? (
                <>
                  <Square className="w-3.5 h-3.5" />
                  <span>Deselect All</span>
                </>
              ) : (
                <>
                  <CheckSquare className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Select All ({processedTracks.length})</span>
                </>
              )}
            </button>

            <span className="text-xs font-semibold text-cyan-300">
              <strong className="text-white text-sm">{selectedIds.size}</strong> of {processedTracks.length} selected
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Move Button */}
            <button
              onClick={() => handleOpenBatchMoveCopy('move')}
              disabled={selectedIds.size === 0 || isProcessingBatch}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-semibold transition disabled:opacity-40"
              title="Move selected to another folder"
            >
              <MoveRight className="w-3.5 h-3.5" />
              <span>Move ({selectedIds.size})</span>
            </button>

            {/* Copy Button */}
            <button
              onClick={() => handleOpenBatchMoveCopy('copy')}
              disabled={selectedIds.size === 0 || isProcessingBatch}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 text-xs font-semibold transition disabled:opacity-40"
              title="Copy selected to another folder"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copy ({selectedIds.size})</span>
            </button>

            {/* Delete Button */}
            <button
              onClick={() => setBatchDeleteModalOpen(true)}
              disabled={selectedIds.size === 0 || isProcessingBatch}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold transition disabled:opacity-40 shadow-sm"
              title="Delete selected recordings"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete ({selectedIds.size})</span>
            </button>

            <button
              onClick={() => {
                setIsBatchMode(false);
                setSelectedIds(new Set());
              }}
              className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
              title="Exit Batch Mode"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Tracks List */}
      {processedTracks.length === 0 ? (
        <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-12 text-center">
          <Music className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <p className="text-base font-medium text-slate-300">{emptyMessage}</p>
          <p className="text-xs text-slate-400 mt-1">
            Upload a .ZIP file or individual audio files to populate this list.
          </p>
        </div>
      ) : (
        <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl divide-y divide-slate-800/60 overflow-hidden">
          {visibleTracks.map((track) => {
            const isCurrent = currentTrack?.id === track.id;
            const isCurrentlyPlaying = isCurrent && isPlaying;
            const isSelected = selectedIds.has(track.id);

            return (
              <div
                key={track.id}
                onClick={() => {
                  if (isBatchMode) {
                    toggleSelectTrack(track.id);
                  }
                }}
                className={`group flex items-center justify-between p-3 sm:px-4 transition ${
                  isSelected
                    ? 'bg-cyan-950/70 border-l-4 border-l-cyan-400'
                    : isCurrent
                    ? 'bg-gradient-to-r from-cyan-950/50 via-slate-900 to-indigo-950/40 border-l-4 border-l-cyan-400'
                    : 'hover:bg-slate-800/40'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {/* Checkbox when in Batch Mode */}
                  {isBatchMode ? (
                    <div
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSelectTrack(track.id);
                      }}
                      className={`w-8 h-8 rounded-xl flex items-center justify-center cursor-pointer transition ${
                        isSelected
                          ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25 ring-2 ring-cyan-400/40'
                          : 'border-2 border-slate-600 hover:border-cyan-400'
                      }`}
                    >
                      {isSelected && <Check className="w-4 h-4 stroke-[3]" />}
                    </div>
                  ) : (
                    /* Play Button in normal mode */
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        if (isCurrent) {
                          togglePlayPause();
                        } else {
                          playTrack(track, processedTracks);
                        }
                      }}
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition ${
                        isCurrentlyPlaying
                          ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/25 ring-2 ring-cyan-400/40'
                          : 'bg-slate-800 text-slate-300 hover:bg-cyan-500 hover:text-slate-950 border border-slate-700/70'
                      }`}
                    >
                      {isCurrentlyPlaying ? (
                        <Pause className="w-4 h-4 fill-current" />
                      ) : (
                        <Play className="w-4 h-4 fill-current ml-0.5" />
                      )}
                    </button>
                  )}

                  <div className="min-w-0 flex-1">
                    <p
                      onClick={(e) => {
                        if (!isBatchMode) {
                          e.stopPropagation();
                          if (!isCurrent) playTrack(track, processedTracks);
                          setIsExpanded(true);
                        }
                      }}
                      className={`text-sm font-medium truncate cursor-pointer hover:underline ${
                        isSelected
                          ? 'text-cyan-200 font-bold'
                          : isCurrent
                          ? 'text-cyan-300 font-semibold'
                          : 'text-slate-200'
                      }`}
                    >
                      {track.title}
                    </p>

                    <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-400">
                      {onNavigateFolder && track.folder && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onNavigateFolder(track.folder);
                          }}
                          className="flex items-center gap-1 text-slate-400 hover:text-cyan-300 truncate transition"
                        >
                          <Folder className="w-3 h-3 text-amber-400/80 shrink-0" />
                          <span className="truncate">{track.folder}</span>
                        </button>
                      )}
                      <span>•</span>
                      <span>{formatBytes(track.size)}</span>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatDuration(track.duration)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right Actions */}
                {!isBatchMode && (
                  <div className="flex items-center gap-1 ml-2 shrink-0">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(track.id);
                      }}
                      className={`p-2 rounded-lg transition ${
                        track.favorite
                          ? 'text-rose-500 hover:text-rose-400'
                          : 'text-slate-400 hover:text-rose-400 hover:bg-slate-800'
                      }`}
                      title={track.favorite ? 'Remove from favorites' : 'Add to favorites'}
                    >
                      <Heart className={`w-4 h-4 ${track.favorite ? 'fill-current' : ''}`} />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownload(track);
                      }}
                      className="p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition"
                      title="Download audio recording"
                    >
                      <Download className="w-4 h-4" />
                    </button>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteTrack(track.id);
                      }}
                      className="p-2 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                      title="Delete recording from vault"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Infinite scrolling 'Load More' */}
      {visibleCount < processedTracks.length && (
        <div className="text-center pt-2">
          <button
            onClick={() => setVisibleCount((prev) => prev + 60)}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-300 border border-slate-700 transition"
          >
            Load Next 60 Recordings ({processedTracks.length - visibleCount} remaining)
          </button>
        </div>
      )}

      {/* BATCH MOVE OR COPY MODAL */}
      {batchActionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2 mb-2">
              {batchActionType === 'move' ? (
                <MoveRight className="w-5 h-5 text-amber-400" />
              ) : (
                <Copy className="w-5 h-5 text-indigo-400" />
              )}
              <span className="capitalize">Batch {batchActionType} ({selectedIds.size} recordings)</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Select destination folder to {batchActionType} {selectedIds.size} recordings in one go:
            </p>
            <form onSubmit={submitBatchMoveCopy} className="space-y-4">
              <div>
                <label className="block text-xs text-slate-300 mb-1.5 font-medium">
                  Select Existing Destination Folder:
                </label>
                <select
                  value={targetFolderSelect}
                  onChange={(e) => setTargetFolderSelect(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-200 focus:outline-none focus:border-cyan-400"
                >
                  <option value="Root">Root (Home Directory)</option>
                  {allFolderPaths
                    .filter((f) => f && f !== 'Root')
                    .map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                </select>
              </div>

              <div>
                <label className="block text-xs text-slate-300 mb-1.5 font-medium">
                  Or Type a New Target Folder Path:
                </label>
                <input
                  type="text"
                  placeholder="e.g. Lectures/Sem 2, Voice Memos/Archived"
                  value={customTargetFolder}
                  onChange={(e) => setCustomTargetFolder(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-xs text-slate-200 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setBatchActionModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessingBatch}
                  className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs capitalize"
                >
                  {isProcessingBatch ? 'Processing...' : `Confirm Batch ${batchActionType}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* BATCH DELETE CONFIRMATION MODAL */}
      {batchDeleteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="bg-slate-900 border border-rose-500/40 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-rose-400" />
              <span>Delete {selectedIds.size} Selected Recordings?</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to delete these {selectedIds.size} recordings from your browser storage? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setBatchDeleteModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isProcessingBatch}
                onClick={handleExecuteBatchDelete}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs"
              >
                {isProcessingBatch ? 'Deleting...' : `Delete ${selectedIds.size} Recordings`}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
