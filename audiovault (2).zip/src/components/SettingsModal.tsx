import React, { useState, useEffect } from 'react';
import {
  Settings,
  X,
  HardDrive,
  Trash2,
  Sparkles,
  Shield,
  Volume2,
  Clock,
  Download,
  AlertTriangle,
  User,
  Heart,
  Check,
} from 'lucide-react';
import { getStorageEstimate, clearAllVault } from '../services/storage';
import { usePlayer } from '../context/PlayerContext';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onClearStorage: () => void;
}

function formatBytes(bytes: number): string {
  if (!bytes) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(1))} ${sizes[i]}`;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onClearStorage,
}) => {
  const { playbackRate, setPlaybackRate } = usePlayer();
  const [storageInfo, setStorageInfo] = useState<{
    usedBytes: number;
    quotaBytes: number;
    percentUsed: number;
    trackCount: number;
  }>({
    usedBytes: 0,
    quotaBytes: 0,
    percentUsed: 0,
    trackCount: 0,
  });

  const [confirmDelete, setConfirmDelete] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [skipInterval, setSkipInterval] = useState<number>(() => {
    return parseInt(localStorage.getItem('vv_skip_interval') || '10', 10);
  });

  useEffect(() => {
    if (isOpen) {
      getStorageEstimate().then(setStorageInfo);
      setConfirmDelete(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClear = async () => {
    setIsClearing(true);
    await clearAllVault();
    setIsClearing(false);
    setConfirmDelete(false);
    onClearStorage();
    onClose();
  };

  const handleSkipIntervalChange = (val: number) => {
    setSkipInterval(val);
    localStorage.setItem('vv_skip_interval', val.toString());
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Application Settings</h3>
              <p className="text-xs text-slate-400">Audio playback, offline storage, & credits</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-5 py-4 pr-1">
          {/* PROMINENT CREATOR TAG SECTION AS REQUESTED */}
          <div className="relative p-5 rounded-2xl bg-gradient-to-br from-indigo-950/80 via-slate-900 to-cyan-950/70 border-2 border-cyan-500/40 shadow-xl overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-400/10 rounded-full blur-2xl group-hover:scale-125 transition-transform" />

            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-indigo-500 text-slate-950 flex items-center justify-center font-black text-xl shadow-lg shadow-cyan-500/30">
                  M
                </div>
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-cyan-500/20 border border-cyan-400/50 text-[11px] font-bold text-cyan-300 tracking-wide uppercase">
                    <Sparkles className="w-3 h-3 text-cyan-300" />
                    Developer Tag
                  </div>
                  <h4 className="text-lg font-bold text-slate-100 mt-1">
                    Created by Meheraj
                  </h4>
                  <p className="text-xs text-slate-300">
                    Lead Architect & Engineer
                  </p>
                </div>
              </div>
            </div>

            <p className="mt-3 text-xs text-slate-300/90 leading-relaxed">
              Designed specially to solve the problem of zip recordings flooding the phone media gallery.
              Powered by sandboxed client-side IndexedDB, high-fidelity audio controls, and full PWA offline support.
            </p>

            <div className="mt-3 pt-3 border-t border-slate-700/60 flex items-center justify-between text-[11px] text-cyan-300 font-mono">
              <span>VocalVault v1.0.0</span>
              <span className="flex items-center gap-1 text-slate-400">
                Crafted with <Heart className="w-3 h-3 text-rose-500 fill-current" /> by Meheraj
              </span>
            </div>
          </div>

          {/* Storage Information */}
          <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-cyan-400" />
                <h4 className="text-sm font-semibold text-slate-200">
                  Browser Storage Vault
                </h4>
              </div>
              <span className="text-xs font-mono text-cyan-300">
                {storageInfo.trackCount} recordings
              </span>
            </div>

            <div className="space-y-1.5">
              <div className="flex justify-between text-xs text-slate-400">
                <span>Storage In Use</span>
                <span>
                  {formatBytes(storageInfo.usedBytes)}
                  {storageInfo.quotaBytes > 0 && ` of ${formatBytes(storageInfo.quotaBytes)}`}
                </span>
              </div>
              <div className="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-700">
                <div
                  className="bg-cyan-500 h-full rounded-full"
                  style={{ width: `${Math.max(2, storageInfo.percentUsed)}%` }}
                />
              </div>
            </div>

            <p className="text-[11px] text-slate-400">
              Recordings are held exclusively inside this browser's IndexedDB. They are never sent to external servers and will not mix into your phone's personal gallery or native music player.
            </p>

            {/* Clear Vault Option */}
            <div className="pt-2 border-t border-slate-800">
              {confirmDelete ? (
                <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 space-y-2">
                  <p className="text-xs text-rose-200 font-medium flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    Are you sure? This will delete all {storageInfo.trackCount} recordings from browser storage.
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={handleClear}
                      disabled={isClearing}
                      className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs transition"
                    >
                      {isClearing ? 'Deleting...' : 'Yes, Delete Everything'}
                    </button>
                    <button
                      onClick={() => setConfirmDelete(false)}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs transition"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setConfirmDelete(true)}
                  className="flex items-center gap-2 text-xs text-rose-400 hover:text-rose-300 py-1 transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Clear all recordings from browser storage</span>
                </button>
              )}
            </div>
          </div>

          {/* Audio Playback Preferences */}
          <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-4">
            <div className="flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-indigo-400" />
              <h4 className="text-sm font-semibold text-slate-200">
                Playback Preferences
              </h4>
            </div>

            {/* Default Seek Interval */}
            <div>
              <label className="block text-xs text-slate-400 mb-2">
                Fast Forward / Rewind Jump Buttons:
              </label>
              <div className="flex gap-2">
                {[5, 10, 15, 30].map((sec) => (
                  <button
                    key={sec}
                    onClick={() => handleSkipIntervalChange(sec)}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-medium transition ${
                      skipInterval === sec
                        ? 'bg-indigo-600 text-white font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    ±{sec}s
                  </button>
                ))}
              </div>
            </div>

            {/* Playback speed presets */}
            <div>
              <label className="block text-xs text-slate-400 mb-2">
                Current Playback Speed Rate:
              </label>
              <div className="flex items-center justify-between gap-1">
                {[0.75, 1.0, 1.25, 1.5, 2.0].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => setPlaybackRate(rate)}
                    className={`flex-1 py-1 rounded-lg text-xs font-mono font-medium transition ${
                      playbackRate === rate
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {rate}x
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Subtitles & Offline Sync Section */}
          <div className="p-4 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <h4 className="text-sm font-semibold text-slate-200">
                English Subtitles & Offline Sync
              </h4>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              When connected to WiFi or mobile data, all English recordings can have synchronized subtitles generated and saved directly to your browser's private storage. Once saved, they work <strong>100% offline</strong> without internet!
            </p>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700/60 text-xs text-slate-400 space-y-1">
              <div className="flex items-center justify-between">
                <span>Offline Subtitles Cache:</span>
                <span className="font-semibold text-emerald-400">IndexedDB Storage</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Subtitles Format:</span>
                <span className="font-mono text-cyan-300">Synchronized Cues (.SRT / .VTT)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          <span className="font-semibold text-cyan-400">
            Created by Meheraj
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
