import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Repeat,
  Repeat1,
  Shuffle,
  ChevronUp,
  ChevronDown,
  Gauge,
  Folder,
  Music,
  Heart,
  ListMusic,
  Sparkles,
  Sliders,
  Subtitles,
  Disc,
} from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { SoundEqualizer } from './SoundEqualizer';
import { SubtitlesView } from './SubtitlesView';

function formatDuration(sec: number): string {
  if (!sec || !Number.isFinite(sec)) return '0:00';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

const SPEED_PRESETS = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];

export const AudioPlayerBar: React.FC<{ onToggleFavorite?: (id: string) => void }> = ({
  onToggleFavorite,
}) => {
  const {
    currentTrack,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    playbackRate,
    repeat,
    isShuffle,
    togglePlayPause,
    seek,
    seekRelative,
    setVolume,
    toggleMute,
    setPlaybackRate,
    toggleRepeat,
    toggleShuffle,
    playNext,
    playPrev,
    queue,
    queueIndex,
    isExpanded,
    setIsExpanded,
    activeSubtitle,
    subtitles,
  } = usePlayer();

  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showQueueDrawer, setShowQueueDrawer] = useState(false);
  const [expandedTab, setExpandedTab] = useState<'player' | 'equalizer' | 'subtitles'>('player');
  const speedMenuRef = useRef<HTMLDivElement>(null);

  // Close speed popup if clicked outside
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (speedMenuRef.current && !speedMenuRef.current.contains(e.target as Node)) {
        setShowSpeedMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  if (!currentTrack) {
    return null;
  }

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <>
      {/* Mini Player Bar (Fixed Bottom) - Click anywhere to expand like Spotify/Apple Music! */}
      <div
        onClick={() => setIsExpanded(true)}
        className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-2xl border-t border-slate-800/90 shadow-2xl safe-area-bottom cursor-pointer select-none group"
        title="Tap to expand full player"
      >
        {/* Seekbar on top edge of player bar */}
        <div
          onClick={(e) => e.stopPropagation()}
          className="relative group/seek w-full h-2 cursor-pointer bg-slate-800/80 -mt-1 hover:h-3 transition-all"
        >
          <div
            className="h-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-500 relative transition-all"
            style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
          >
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md scale-0 group-hover/seek:scale-100 transition-transform" />
          </div>
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={(e) => seek(parseFloat(e.target.value))}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            title="Seek playback"
          />
        </div>

        <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2 sm:gap-6">
          {/* Left: Track Information & Tap to expand indicator */}
          <div className="flex items-center gap-3 min-w-0 max-w-[42%] sm:max-w-[32%]">
            <div className="relative w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-900/80 to-slate-900 border border-indigo-500/30 flex items-center justify-center shrink-0 shadow-sm group-hover:border-cyan-400/50 transition">
              <Music className={`w-5 h-5 text-cyan-400 ${isPlaying ? 'animate-pulse' : ''}`} />
              <div className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-cyan-400 rounded-full animate-ping opacity-60" />
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <p className="text-sm font-semibold text-slate-100 truncate group-hover:text-cyan-300 transition">
                  {currentTrack.title}
                </p>
                <ChevronUp className="w-3.5 h-3.5 text-cyan-400 group-hover:translate-y-[-2px] transition-transform shrink-0" />
              </div>
              <p className="text-xs text-slate-400 truncate flex items-center gap-1">
                <Folder className="w-3 h-3 text-amber-400/80 shrink-0" />
                <span>{currentTrack.folder || 'Vault'}</span>
              </p>
            </div>
          </div>

          {/* Center: Live Subtitle Snippet or Core Controls */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex flex-col items-center flex-1 max-w-xl"
          >
            {/* Realtime Subtitle Preview Banner if active */}
            {activeSubtitle && (
              <div
                onClick={() => {
                  setExpandedTab('subtitles');
                  setIsExpanded(true);
                }}
                className="mb-1 hidden md:flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-indigo-950/70 border border-indigo-500/40 text-[11px] text-cyan-200 cursor-pointer hover:bg-indigo-900/80 transition truncate max-w-md shadow-sm"
                title="Click to view full English subtitles"
              >
                <Subtitles className="w-3 h-3 text-cyan-400 shrink-0" />
                <span className="truncate">"{activeSubtitle.text}"</span>
              </div>
            )}

            <div className="flex items-center gap-1.5 sm:gap-3">
              {/* Shuffle */}
              <button
                onClick={toggleShuffle}
                className={`p-1.5 sm:p-2 rounded-lg transition ${
                  isShuffle
                    ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title={isShuffle ? 'Shuffle enabled' : 'Shuffle disabled'}
              >
                <Shuffle className="w-4 h-4" />
              </button>

              {/* Jump -10s */}
              <button
                onClick={() => seekRelative(-10)}
                className="p-1.5 sm:p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition relative"
                title="Rewind 10 seconds"
              >
                <RotateCcw className="w-4 h-4" />
                <span className="absolute text-[8px] font-bold bottom-1 left-1/2 -translate-x-1/2 text-slate-400">
                  10
                </span>
              </button>

              {/* Previous */}
              <button
                onClick={playPrev}
                className="p-1.5 sm:p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
                title="Previous track"
              >
                <SkipBack className="w-5 h-5 fill-current" />
              </button>

              {/* Big Play/Pause Button */}
              <button
                onClick={togglePlayPause}
                className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-gradient-to-r from-cyan-400 to-indigo-600 text-slate-950 font-bold flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-lg shadow-cyan-500/25 ring-2 ring-cyan-400/30"
                title={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 sm:w-6 sm:h-6 fill-current" />
                ) : (
                  <Play className="w-5 h-5 sm:w-6 sm:h-6 fill-current ml-0.5" />
                )}
              </button>

              {/* Next */}
              <button
                onClick={playNext}
                className="p-1.5 sm:p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition"
                title="Next track"
              >
                <SkipForward className="w-5 h-5 fill-current" />
              </button>

              {/* Jump +10s */}
              <button
                onClick={() => seekRelative(10)}
                className="p-1.5 sm:p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition relative"
                title="Forward 10 seconds"
              >
                <RotateCw className="w-4 h-4" />
                <span className="absolute text-[8px] font-bold bottom-1 left-1/2 -translate-x-1/2 text-slate-400">
                  10
                </span>
              </button>

              {/* Repeat */}
              <button
                onClick={toggleRepeat}
                className={`p-1.5 sm:p-2 rounded-lg transition ${
                  repeat !== 'off'
                    ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
                title={`Repeat: ${repeat}`}
              >
                {repeat === 'one' ? <Repeat1 className="w-4 h-4" /> : <Repeat className="w-4 h-4" />}
              </button>
            </div>

            {/* Time labels under controls */}
            <div className="w-full flex items-center justify-between text-[11px] font-mono text-slate-400 px-1 mt-0.5 max-w-sm">
              <span>{formatDuration(currentTime)}</span>
              <span className="text-[10px] text-slate-400 font-sans hidden sm:inline">
                Tap bar to expand full player • by Meheraj
              </span>
              <span>{formatDuration(duration)}</span>
            </div>
          </div>

          {/* Right: Quick actions: EQ button, Subtitles button, Speed pill, Volume */}
          <div
            onClick={(e) => e.stopPropagation()}
            className="flex items-center gap-1 sm:gap-2 shrink-0"
          >
            {/* Quick Sound Controller (EQ) shortcut */}
            <button
              onClick={() => {
                setExpandedTab('equalizer');
                setIsExpanded(true);
              }}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-cyan-400 border border-slate-700/80 transition"
              title="Sound Controller & Hz Equalizer"
            >
              <Sliders className="w-4 h-4" />
            </button>

            {/* Quick English Subtitles shortcut */}
            <button
              onClick={() => {
                setExpandedTab('subtitles');
                setIsExpanded(true);
              }}
              className={`p-2 rounded-xl border transition ${
                subtitles.length > 0
                  ? 'bg-indigo-950/80 border-indigo-500/50 text-indigo-300'
                  : 'bg-slate-800/80 border-slate-700/80 text-slate-400 hover:text-white'
              }`}
              title="English Subtitles & Transcripts"
            >
              <Subtitles className="w-4 h-4" />
            </button>

            {/* Speed Control Pill */}
            <div className="relative" ref={speedMenuRef}>
              <button
                onClick={() => setShowSpeedMenu(!showSpeedMenu)}
                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-xs font-semibold font-mono text-cyan-300 border border-slate-700/80 transition"
                title="Playback Speed"
              >
                <Gauge className="w-3.5 h-3.5" />
                <span>{playbackRate}x</span>
              </button>

              {showSpeedMenu && (
                <div className="absolute right-0 bottom-full mb-2 w-48 bg-slate-900 border border-slate-700/90 rounded-2xl p-2.5 shadow-2xl z-50 animate-in fade-in slide-in-from-bottom-2">
                  <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2 px-1">
                    Playback Speed
                  </div>
                  <div className="grid grid-cols-3 gap-1.5 mb-3">
                    {SPEED_PRESETS.map((rate) => (
                      <button
                        key={rate}
                        onClick={() => {
                          setPlaybackRate(rate);
                          setShowSpeedMenu(false);
                        }}
                        className={`py-1 rounded-lg text-xs font-mono font-medium transition ${
                          playbackRate === rate
                            ? 'bg-cyan-500 text-slate-950 font-bold'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                        }`}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>

                  {/* Fine Speed Slider */}
                  <div className="pt-2 border-t border-slate-800 px-1">
                    <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                      <span>Fine Slider:</span>
                      <span className="font-mono text-cyan-300 font-bold">
                        {playbackRate.toFixed(2)}x
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.5}
                      max={2.5}
                      step={0.05}
                      value={playbackRate}
                      onChange={(e) => setPlaybackRate(parseFloat(e.target.value))}
                      className="w-full accent-cyan-400 cursor-pointer"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Volume Control */}
            <div className="hidden lg:flex items-center gap-2">
              <button
                onClick={toggleMute}
                className="p-1.5 text-slate-400 hover:text-white"
                title={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.02}
                value={isMuted ? 0 : volume}
                onChange={(e) => {
                  if (isMuted) toggleMute();
                  setVolume(parseFloat(e.target.value));
                }}
                className="w-16 accent-cyan-400 h-1.5 bg-slate-800 rounded-lg cursor-pointer"
              />
            </div>

            {/* Queue Drawer Toggle */}
            <button
              onClick={() => setShowQueueDrawer(!showQueueDrawer)}
              className={`p-2 rounded-lg transition relative ${
                showQueueDrawer
                  ? 'bg-cyan-500/20 text-cyan-300'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
              title="Play Queue"
            >
              <ListMusic className="w-4 h-4" />
              {queue.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-500 text-slate-950 text-[9px] font-bold flex items-center justify-center">
                  {queue.length > 99 ? '99+' : queue.length}
                </span>
              )}
            </button>

            {/* Expand Player Button */}
            <button
              onClick={() => setIsExpanded(true)}
              className="p-2 rounded-lg text-cyan-400 hover:bg-cyan-500/10 transition"
              title="Expand Full Player"
            >
              <ChevronUp className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Slide-Up Queue Drawer */}
      {showQueueDrawer && (
        <div className="fixed inset-x-0 bottom-20 z-50 max-w-lg mx-auto p-4 animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="bg-slate-900/98 backdrop-blur-2xl border border-slate-700/80 rounded-3xl p-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <ListMusic className="w-4 h-4 text-cyan-400" />
                <h4 className="text-sm font-semibold text-slate-100">Up Next ({queue.length})</h4>
              </div>
              <button
                onClick={() => setShowQueueDrawer(false)}
                className="text-xs px-2 py-1 rounded bg-slate-800 text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="max-h-64 overflow-y-auto mt-2 divide-y divide-slate-800/60 pr-1">
              {queue.map((track, idx) => {
                const isCurrent = idx === queueIndex;
                return (
                  <div
                    key={track.id + idx}
                    className={`flex items-center justify-between py-2 px-2 rounded-xl transition ${
                      isCurrent
                        ? 'bg-cyan-950/60 text-cyan-300 font-semibold border-l-2 border-cyan-400'
                        : 'text-slate-300 hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-xs font-mono text-slate-400 w-5 text-right">
                        {idx + 1}
                      </span>
                      <div className="min-w-0">
                        <p className="text-xs font-medium truncate">{track.title}</p>
                        <p className="text-[10px] text-slate-400 truncate">{track.folder}</p>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-slate-400 shrink-0">
                      {formatDuration(track.duration)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* FULL-SCREEN / EXPANDED IMMERSIVE MUSIC PLAYER (Like Spotify / Apple Music) */}
      {isExpanded && (
        <div className="fixed inset-0 z-50 bg-[#090d16]/98 backdrop-blur-3xl flex flex-col p-4 sm:p-8 animate-in fade-in slide-in-from-bottom-8 duration-250 overflow-y-auto">
          {/* Top Bar with Collapse, Tabs & Favorite */}
          <div className="flex items-center justify-between max-w-2xl mx-auto w-full mb-4 shrink-0">
            <button
              onClick={() => setIsExpanded(false)}
              className="p-2.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white shadow-sm"
              title="Collapse Player"
            >
              <ChevronDown className="w-5 h-5" />
            </button>

            {/* Tab Selector: Now Playing vs Equalizer vs English Subtitles */}
            <div className="flex items-center gap-1 p-1 bg-slate-900/90 rounded-2xl border border-slate-800 shadow-inner">
              <button
                onClick={() => setExpandedTab('player')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  expandedTab === 'player'
                    ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Disc className="w-3.5 h-3.5" />
                <span>Player</span>
              </button>

              <button
                onClick={() => setExpandedTab('equalizer')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  expandedTab === 'equalizer'
                    ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Sound (Hz)</span>
              </button>

              <button
                onClick={() => setExpandedTab('subtitles')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition ${
                  expandedTab === 'subtitles'
                    ? 'bg-cyan-500 text-slate-950 shadow-md font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Subtitles className="w-3.5 h-3.5" />
                <span>Subtitles</span>
              </button>
            </div>

            {onToggleFavorite ? (
              <button
                onClick={() => onToggleFavorite(currentTrack.id)}
                className={`p-2.5 rounded-2xl border transition shadow-sm ${
                  currentTrack.favorite
                    ? 'bg-rose-950/60 border-rose-500/40 text-rose-400'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                }`}
                title="Favorite"
              >
                <Heart className={`w-5 h-5 ${currentTrack.favorite ? 'fill-current' : ''}`} />
              </button>
            ) : (
              <div className="w-10" />
            )}
          </div>

          {/* Tab 1: Full Player View */}
          {expandedTab === 'player' && (
            <div className="flex-1 flex flex-col items-center justify-center max-w-xl mx-auto w-full my-auto py-2">
              {/* Artwork & Rotating Sound Disc */}
              <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-3xl bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 border border-cyan-500/20 shadow-2xl flex items-center justify-center p-6 mb-6">
                <div
                  className={`absolute inset-4 rounded-full border border-cyan-500/20 ${
                    isPlaying ? 'animate-spin' : ''
                  }`}
                  style={{ animationDuration: '18s' }}
                />
                <div className="w-32 h-32 rounded-full bg-gradient-to-br from-cyan-500/20 via-indigo-500/20 to-purple-500/20 border border-cyan-400/30 flex items-center justify-center shadow-inner">
                  <Music className="w-14 h-14 text-cyan-300 drop-shadow-lg" />
                </div>

                {/* Animated Equalizer bars */}
                {isPlaying && (
                  <div className="absolute bottom-5 flex items-center gap-1.5">
                    <span className="w-1.5 h-6 bg-cyan-400 animate-pulse rounded-full" />
                    <span className="w-1.5 h-10 bg-indigo-400 animate-pulse delay-100 rounded-full" />
                    <span className="w-1.5 h-7 bg-purple-400 animate-pulse delay-200 rounded-full" />
                    <span className="w-1.5 h-4 bg-cyan-400 animate-pulse delay-75 rounded-full" />
                  </div>
                )}
              </div>

              {/* Live Subtitle Line Display right under artwork */}
              {activeSubtitle ? (
                <div
                  onClick={() => setExpandedTab('subtitles')}
                  className="w-full bg-indigo-950/60 border border-indigo-500/40 rounded-2xl p-3 mb-4 text-center cursor-pointer hover:bg-indigo-900/60 transition shadow-lg"
                  title="Click to view full subtitles"
                >
                  <p className="text-xs uppercase tracking-wider text-cyan-400 font-bold mb-0.5 flex items-center justify-center gap-1">
                    <Subtitles className="w-3.5 h-3.5" /> English Subtitle
                  </p>
                  <p className="text-sm font-semibold text-white drop-shadow">
                    "{activeSubtitle.text}"
                  </p>
                </div>
              ) : null}

              {/* Title & Folder */}
              <div className="text-center w-full px-4 mb-4">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-100 truncate">
                  {currentTrack.title}
                </h2>
                <p className="text-xs sm:text-sm text-cyan-400/90 mt-1 flex items-center justify-center gap-1.5 truncate">
                  <Folder className="w-4 h-4 text-amber-400" />
                  <span>{currentTrack.folder || 'Vault Recordings'}</span>
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5 font-medium">
                  Created by Meheraj
                </p>
              </div>

              {/* Seekbar */}
              <div className="w-full px-2 mb-4">
                <div className="relative group w-full h-3 cursor-pointer bg-slate-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-500 rounded-full"
                    style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
                  />
                  <input
                    type="range"
                    min={0}
                    max={duration || 100}
                    step={0.1}
                    value={currentTime}
                    onChange={(e) => seek(parseFloat(e.target.value))}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between text-xs font-mono text-slate-400 mt-2 px-1">
                  <span>{formatDuration(currentTime)}</span>
                  <span>{formatDuration(duration)}</span>
                </div>
              </div>

              {/* Core Playback Buttons */}
              <div className="flex items-center justify-between w-full px-4 mb-5">
                <button
                  onClick={toggleShuffle}
                  className={`p-3 rounded-2xl transition ${
                    isShuffle ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <Shuffle className="w-5 h-5" />
                </button>

                <button
                  onClick={() => seekRelative(-10)}
                  className="p-3 rounded-2xl text-slate-400 hover:text-white relative"
                  title="Rewind 10s"
                >
                  <RotateCcw className="w-6 h-6" />
                  <span className="absolute text-[9px] font-bold bottom-1.5 left-1/2 -translate-x-1/2">
                    10
                  </span>
                </button>

                <button onClick={playPrev} className="p-3 rounded-2xl text-slate-300 hover:text-white">
                  <SkipBack className="w-7 h-7 fill-current" />
                </button>

                <button
                  onClick={togglePlayPause}
                  className="w-16 h-16 rounded-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-500 text-slate-950 font-bold flex items-center justify-center hover:scale-105 active:scale-95 transition shadow-xl shadow-cyan-500/30 ring-4 ring-cyan-400/20"
                >
                  {isPlaying ? (
                    <Pause className="w-7 h-7 fill-current" />
                  ) : (
                    <Play className="w-7 h-7 fill-current ml-1" />
                  )}
                </button>

                <button onClick={playNext} className="p-3 rounded-2xl text-slate-300 hover:text-white">
                  <SkipForward className="w-7 h-7 fill-current" />
                </button>

                <button
                  onClick={() => seekRelative(10)}
                  className="p-3 rounded-2xl text-slate-400 hover:text-white relative"
                  title="Forward 10s"
                >
                  <RotateCw className="w-6 h-6" />
                  <span className="absolute text-[9px] font-bold bottom-1.5 left-1/2 -translate-x-1/2">
                    10
                  </span>
                </button>

                <button
                  onClick={toggleRepeat}
                  className={`p-3 rounded-2xl transition ${
                    repeat !== 'off' ? 'text-cyan-400 bg-cyan-950/60 border border-cyan-500/40' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {repeat === 'one' ? <Repeat1 className="w-5 h-5" /> : <Repeat className="w-5 h-5" />}
                </button>
              </div>

              {/* Speed Presets */}
              <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-3 mb-4">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Gauge className="w-3.5 h-3.5 text-cyan-400" /> Playback Speed
                  </span>
                  <span className="font-mono text-cyan-300 font-bold">{playbackRate.toFixed(2)}x</span>
                </div>
                <div className="flex items-center justify-between gap-1">
                  {SPEED_PRESETS.map((rate) => (
                    <button
                      key={rate}
                      onClick={() => setPlaybackRate(rate)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-mono font-medium transition ${
                        playbackRate === rate
                          ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/25'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {rate}x
                    </button>
                  ))}
                </div>
              </div>

              {/* Volume Slider */}
              <div className="w-full flex items-center gap-3 px-2">
                <button onClick={toggleMute} className="p-2 text-slate-400 hover:text-white">
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-5 h-5 text-rose-400" />
                  ) : (
                    <Volume2 className="w-5 h-5" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.02}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    if (isMuted) toggleMute();
                    setVolume(parseFloat(e.target.value));
                  }}
                  className="flex-1 accent-cyan-400 h-2 bg-slate-800 rounded-lg cursor-pointer"
                />
                <span className="text-xs font-mono text-slate-400 w-10 text-right">
                  {Math.round((isMuted ? 0 : volume) * 100)}%
                </span>
              </div>
            </div>
          )}

          {/* Tab 2: Sound Controller & Hz Equalizer */}
          {expandedTab === 'equalizer' && (
            <div className="flex-1 max-w-2xl mx-auto w-full my-auto py-2">
              <SoundEqualizer />
            </div>
          )}

          {/* Tab 3: English Subtitles */}
          {expandedTab === 'subtitles' && (
            <div className="flex-1 max-w-2xl mx-auto w-full my-auto py-2">
              <SubtitlesView />
            </div>
          )}
        </div>
      )}
    </>
  );
};
