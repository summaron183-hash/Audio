import React, { useState } from 'react';
import {
  Download,
  Monitor,
  Smartphone,
  Apple,
  X,
  CheckCircle,
  ExternalLink,
  Sparkles,
  Share2,
  PlusSquare,
  MoreVertical,
  Laptop,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface InstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallModal: React.FC<InstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [activeTab, setActiveTab] = useState<'desktop' | 'android' | 'ios'>(
    isIOS ? 'ios' : 'desktop'
  );
  const [installSuccess, setInstallSuccess] = useState(false);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    const success = await install();
    if (success) {
      setInstallSuccess(true);
      setTimeout(() => {
        onClose();
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/90 rounded-3xl max-w-xl w-full p-6 shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh]">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-44 h-44 bg-cyan-500/10 blur-3xl rounded-full pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">
                Installation Manual & Offline Setup
              </h3>
              <p className="text-xs text-slate-400">
                Install as a standalone app on your devices • Created by Meheraj
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* In-App Direct Install Button if supported */}
        {isInstallable && !isInstalled && (
          <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-indigo-950/60 border border-cyan-500/40 flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-bold text-cyan-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> One-Click Install Available!
              </p>
              <p className="text-xs text-slate-300 mt-0.5">
                Chrome is ready to install VocalVault directly to your desktop or home screen.
              </p>
            </div>
            <button
              onClick={handleInstallClick}
              className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shrink-0 transition shadow-lg shadow-cyan-500/25 active:scale-95"
            >
              {installSuccess ? 'Installed!' : 'Install Now'}
            </button>
          </div>
        )}

        {isInstalled && (
          <div className="my-4 p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center gap-2.5 text-xs text-emerald-300">
            <CheckCircle className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>VocalVault is already installed and running as a standalone app!</span>
          </div>
        )}

        {/* Tab switcher */}
        <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-950/60 rounded-xl border border-slate-800 my-3">
          <button
            onClick={() => setActiveTab('desktop')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold transition ${
              activeTab === 'desktop'
                ? 'bg-slate-800 text-cyan-300 shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Laptop className="w-4 h-4" />
            <span>Desktop</span>
          </button>

          <button
            onClick={() => setActiveTab('android')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold transition ${
              activeTab === 'android'
                ? 'bg-slate-800 text-cyan-300 shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>Android</span>
          </button>

          <button
            onClick={() => setActiveTab('ios')}
            className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-semibold transition ${
              activeTab === 'ios'
                ? 'bg-slate-800 text-cyan-300 shadow-sm border border-slate-700'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Apple className="w-4 h-4" />
            <span>iPhone / iPad</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto space-y-4 py-2 pr-1">
          {activeTab === 'desktop' && (
            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-2">
                <h4 className="font-semibold text-sm text-cyan-300 flex items-center gap-2">
                  <span>Method 1: Address Bar Install Icon (Fastest)</span>
                </h4>
                <p>
                  1. Look at the right side of Chrome's address bar (URL bar).
                </p>
                <p>
                  2. Click the <strong>Install</strong> icon (a computer monitor with a downward arrow).
                </p>
                <p>
                  3. In the prompt, click <strong>"Install"</strong>. The app will launch in its own standalone window with its own taskbar/dock icon!
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-2">
                <h4 className="font-semibold text-sm text-cyan-300 flex items-center gap-2">
                  <span>Method 2: Chrome Menu & Desktop Shortcut</span>
                </h4>
                <p>
                  1. Click the <strong>Three Dots (⋮)</strong> menu in the top-right of Chrome.
                </p>
                <p>
                  2. Hover over <strong>"Save and share"</strong> or <strong>"More tools"</strong>.
                </p>
                <p>
                  3. Click <strong>"Install VocalVault..."</strong> or <strong>"Create shortcut..."</strong>.
                </p>
                <p>
                  4. Make sure to check the box <strong>"Open as window"</strong> so it runs like a real software program without browser tabs!
                </p>
              </div>
            </div>
          )}

          {activeTab === 'android' && (
            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-2.5">
                <h4 className="font-semibold text-sm text-cyan-300 flex items-center gap-2">
                  <MoreVertical className="w-4 h-4 text-amber-400" />
                  <span>Google Chrome on Android</span>
                </h4>
                <ol className="list-decimal list-inside space-y-2 text-slate-300">
                  <li>
                    Tap the <strong>three dots (⋮)</strong> in the upper right corner of Google Chrome.
                  </li>
                  <li>
                    Select <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong> from the menu.
                  </li>
                  <li>
                    Tap <strong>"Install"</strong> in the confirmation popup.
                  </li>
                  <li>
                    VocalVault will now appear on your phone home screen and App Drawer just like a native app from the Play Store!
                  </li>
                  <li>
                    <strong>Offline:</strong> Open it anytime, even in airplane mode. All extracted ZIP recordings remain safely stored inside the app.
                  </li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'ios' && (
            <div className="space-y-4 text-xs text-slate-300">
              <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-800 space-y-2.5">
                <h4 className="font-semibold text-sm text-cyan-300 flex items-center gap-2">
                  <Share2 className="w-4 h-4 text-indigo-400" />
                  <span>Apple Safari on iPhone & iPad</span>
                </h4>
                <ol className="list-decimal list-inside space-y-2 text-slate-300">
                  <li>
                    Open this website in <strong>Safari</strong> on your iPhone or iPad.
                  </li>
                  <li>
                    Tap the <strong>Share</strong> button (the square icon with an upward arrow at the bottom toolbar).
                  </li>
                  <li>
                    Scroll down in the action sheet and tap <strong>"Add to Home Screen"</strong> (with the <PlusSquare className="w-3.5 h-3.5 inline text-slate-400" /> plus icon).
                  </li>
                  <li>
                    Tap <strong>"Add"</strong> in the top-right corner.
                  </li>
                  <li>
                    The VocalVault icon will now be on your home screen. When opened, it runs in full screen with zero Safari browser bars!
                  </li>
                </ol>
              </div>
            </div>
          )}
        </div>

        {/* Footer with Attribution */}
        <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
          <span className="font-medium text-slate-300">
            Created by Meheraj
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition font-medium"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
