import React, { useRef, useEffect } from 'react';
import {
  Subtitles,
  Download,
  Upload,
  Sparkles,
  Wifi,
  WifiOff,
  AlertCircle,
  Loader2,
  CheckCircle2,
  FileText,
} from 'lucide-react';
import { usePlayer } from '../context/PlayerContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

function formatTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

export const SubtitlesView: React.FC = () => {
  const {
    currentTrack,
    currentTime,
    seek,
    subtitles,
    activeSubtitle,
    isTranscribing,
    transcriptionError,
    downloadSubtitlesForCurrent,
    importSubtitleFile,
  } = usePlayer();

  const isOnline = useOnlineStatus();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeLineRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to active subtitle
  useEffect(() => {
    if (activeLineRef.current) {
      activeLineRef.current.scrollIntoView({
        behavior: 'smooth',
        block: 'center',
      });
    }
  }, [activeSubtitle]);

  if (!currentTrack) return null;

  return (
    <div className="bg-slate-900/90 border border-slate-700/80 rounded-3xl p-5 shadow-2xl backdrop-blur-xl flex flex-col h-full max-h-[500px]">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <Subtitles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <span>English Subtitles</span>
              {subtitles.length > 0 && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Offline Ready
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400">
              Synchronized transcript & closed captions
            </p>
          </div>
        </div>

        {/* Import custom SRT / VTT */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1 text-xs px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
            title="Import .SRT or .VTT subtitles"
          >
            <Upload className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Import SRT/VTT</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".srt,.vtt,text/vtt,text/plain"
            className="hidden"
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                importSubtitleFile(e.target.files[0]).catch((err) =>
                  console.error('Subtitle import failed:', err)
                );
              }
            }}
          />
        </div>
      </div>

      {/* Subtitles Content Area */}
      <div className="flex-1 overflow-y-auto my-3 pr-1 space-y-2">
        {subtitles.length > 0 ? (
          /* Synchronized subtitles stream */
          <div className="space-y-2 py-2">
            {subtitles.map((cue, idx) => {
              const isActive = activeSubtitle === cue;
              return (
                <div
                  key={idx}
                  ref={isActive ? activeLineRef : null}
                  onClick={() => seek(cue.start)}
                  className={`p-3 rounded-2xl cursor-pointer transition flex items-start gap-3 ${
                    isActive
                      ? 'bg-gradient-to-r from-cyan-950/80 to-indigo-950/80 border-2 border-cyan-400/80 text-white shadow-lg shadow-cyan-950/50 scale-[1.01]'
                      : 'hover:bg-slate-800/50 text-slate-300'
                  }`}
                >
                  <span
                    className={`text-[11px] font-mono px-2 py-0.5 rounded-md shrink-0 mt-0.5 ${
                      isActive
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {formatTime(cue.start)}
                  </span>
                  <p
                    className={`text-sm leading-relaxed ${
                      isActive ? 'font-semibold text-cyan-200' : 'text-slate-300'
                    }`}
                  >
                    {cue.text}
                  </p>
                </div>
              );
            })}
          </div>
        ) : (
          /* Empty / Download state */
          <div className="py-10 text-center space-y-4 px-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto">
              <FileText className="w-7 h-7" />
            </div>

            <div>
              <h4 className="text-sm font-semibold text-slate-200">
                No Subtitles for this recording yet
              </h4>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Generate English subtitles while connected to WiFi or Mobile Data.
                Once downloaded, they are saved to browser storage for <strong>100% offline playback</strong>!
              </p>
            </div>

            {transcriptionError && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-300 flex items-center gap-2 max-w-sm mx-auto text-left">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{transcriptionError}</span>
              </div>
            )}

            <div className="flex flex-col sm:flex-row items-center justify-center gap-2 pt-2">
              <button
                onClick={downloadSubtitlesForCurrent}
                disabled={isTranscribing || !isOnline}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50 shadow-lg shadow-cyan-500/20"
              >
                {isTranscribing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Transcribing English Audio...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Download English Subtitles</span>
                  </>
                )}
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs border border-slate-700 transition"
              >
                Upload .SRT File
              </button>
            </div>

            {!isOnline && (
              <p className="text-[11px] text-amber-400 flex items-center justify-center gap-1">
                <WifiOff className="w-3.5 h-3.5" /> Connect to WiFi or mobile data to download subtitles
              </p>
            )}
          </div>
        )}
      </div>

      {/* Footer status */}
      <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
        <span className="flex items-center gap-1.5">
          {isOnline ? (
            <Wifi className="w-3 h-3 text-emerald-400" />
          ) : (
            <WifiOff className="w-3 h-3 text-amber-400" />
          )}
          <span>{isOnline ? 'Online (Ready to sync)' : 'Offline (Playing cached subtitles)'}</span>
        </span>
        <span className="text-slate-400">Click any line to seek</span>
      </div>
    </div>
  );
};
