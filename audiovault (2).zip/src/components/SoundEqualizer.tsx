import React from 'react';
import { Sliders, RotateCcw, Sparkles, Volume2 } from 'lucide-react';
import { usePlayer, EQ_PRESETS } from '../context/PlayerContext';

export const SoundEqualizer: React.FC = () => {
  const { eqBands, setEqGain, selectedPreset, applyEqPreset, resetEq } = usePlayer();

  return (
    <div className="bg-slate-900/90 border border-slate-700/80 rounded-3xl p-5 shadow-2xl backdrop-blur-xl">
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-1.5">
              <span>Sound Controller & Hz Equalizer</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300">
                Web Audio
              </span>
            </h3>
            <p className="text-xs text-slate-400">
              Fine-tune frequencies for voice clarity, bass, and audio enhancements
            </p>
          </div>
        </div>

        <button
          onClick={resetEq}
          className="flex items-center gap-1 text-xs px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
          title="Reset Equalizer to Flat"
        >
          <RotateCcw className="w-3 h-3" />
          <span>Reset</span>
        </button>
      </div>

      {/* Preset Pills */}
      <div className="mt-4">
        <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
          Equalizer Presets
        </div>
        <div className="flex flex-wrap gap-1.5">
          {EQ_PRESETS.map((p) => (
            <button
              key={p.name}
              onClick={() => applyEqPreset(p.name)}
              className={`px-3 py-1.5 rounded-xl text-xs font-medium transition ${
                selectedPreset === p.name
                  ? 'bg-gradient-to-r from-cyan-500 to-indigo-600 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300 border border-slate-700/60'
              }`}
            >
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Vertical Frequency Sliders (60Hz, 230Hz, 910Hz, 3.6kHz, 14kHz) */}
      <div className="mt-6 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-4">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-4 px-2">
          <span>+12 dB</span>
          <span className="font-mono text-cyan-300 text-[11px]">0 dB (Neutral)</span>
          <span>-12 dB</span>
        </div>

        <div className="grid grid-cols-5 gap-2 sm:gap-4 items-end justify-items-center py-2">
          {eqBands.map((band) => (
            <div key={band.frequency} className="flex flex-col items-center gap-2 w-full">
              {/* dB readout */}
              <span
                className={`text-[10px] font-mono font-bold ${
                  band.gain > 0
                    ? 'text-cyan-400'
                    : band.gain < 0
                    ? 'text-rose-400'
                    : 'text-slate-400'
                }`}
              >
                {band.gain > 0 ? `+${band.gain}` : band.gain} dB
              </span>

              {/* Slider track container */}
              <div className="relative h-36 flex items-center justify-center">
                <input
                  type="range"
                  min={-12}
                  max={12}
                  step={1}
                  value={band.gain}
                  onChange={(e) => setEqGain(band.frequency, parseFloat(e.target.value))}
                  style={{ writingMode: 'vertical-lr', direction: 'rtl' }}
                  className="w-6 h-32 accent-cyan-400 cursor-pointer rounded-lg bg-slate-800"
                />
              </div>

              {/* Frequency Label */}
              <span className="text-xs font-semibold text-slate-200 mt-1">
                {band.label}
              </span>

              {/* Band role hint */}
              <span className="text-[9px] text-slate-400 text-center leading-tight">
                {band.frequency === 60
                  ? 'Sub-bass'
                  : band.frequency === 230
                  ? 'Bass'
                  : band.frequency === 910
                  ? 'Speech/Vocals'
                  : band.frequency === 3600
                  ? 'Clarity'
                  : 'Air/Treble'}
              </span>
            </div>
          ))}
        </div>
      </div>

      <p className="mt-3 text-[11px] text-slate-400 text-center">
        Tip: <strong>Lecture / Speech Clarity</strong> boosts 910Hz & 3.6kHz so voice recordings and lectures sound crisp and clear.
      </p>
    </div>
  );
};
