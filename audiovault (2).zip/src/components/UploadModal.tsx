import React, { useState, useRef } from 'react';
import {
  Upload,
  Archive,
  FileAudio,
  FolderUp,
  X,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';
import {
  extractZipArchive,
  processRawAudioFiles,
  ExtractionProgress,
} from '../services/zipExtractor';
import { addTracksWithBlobs, createDemoVault } from '../services/storage';
import { AudioTrack } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportComplete: (importedTracks: AudioTrack[]) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onImportComplete,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState<ExtractionProgress | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successCount, setSuccessCount] = useState<number | null>(null);

  const zipInputRef = useRef<HTMLInputElement>(null);
  const filesInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleProcessZip = async (file: File) => {
    setIsProcessing(true);
    setErrorMessage(null);
    setSuccessCount(null);

    try {
      const items = await extractZipArchive(file, (p) => {
        setProgress(p);
      });

      // Save to IndexedDB
      await addTracksWithBlobs(items, (done, total) => {
        setProgress({
          stage: 'saving',
          totalFiles: total,
          extractedFiles: done,
          currentFileName: `Saving ${done}/${total} recordings to IndexedDB...`,
          percentage: 90 + Math.round((done / total) * 10),
        });
      });

      setSuccessCount(items.length);
      setIsProcessing(false);
      onImportComplete(items.map((i) => i.track));
    } catch (err: unknown) {
      setIsProcessing(false);
      setErrorMessage(err instanceof Error ? err.message : 'Failed to extract ZIP archive.');
    }
  };

  const handleProcessFiles = async (files: FileList | File[]) => {
    setIsProcessing(true);
    setErrorMessage(null);
    setSuccessCount(null);

    try {
      const items = await processRawAudioFiles(files, (p) => {
        setProgress(p);
      });

      await addTracksWithBlobs(items);
      setSuccessCount(items.length);
      setIsProcessing(false);
      onImportComplete(items.map((i) => i.track));
    } catch (err: unknown) {
      setIsProcessing(false);
      setErrorMessage(err instanceof Error ? err.message : 'Failed to process audio files.');
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.zip')) {
        handleProcessZip(file);
      } else {
        handleProcessFiles(e.dataTransfer.files);
      }
    }
  };

  const handleLoadDemo = async () => {
    setIsProcessing(true);
    setErrorMessage(null);
    setProgress({
      stage: 'extracting',
      totalFiles: 8,
      extractedFiles: 4,
      currentFileName: 'Synthesizing voice notes and audio memos with Web Audio...',
      percentage: 50,
    });

    try {
      const demoTracks = await createDemoVault();
      setSuccessCount(demoTracks.length);
      setIsProcessing(false);
      onImportComplete(demoTracks);
    } catch (err: unknown) {
      setIsProcessing(false);
      setErrorMessage(err instanceof Error ? err.message : 'Could not generate demo tracks.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-lg w-full p-6 shadow-2xl relative overflow-hidden">
        {/* Glow accent */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/10 blur-3xl rounded-full pointer-events-none" />

        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Archive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100">Import Audio Vault</h3>
              <p className="text-xs text-slate-400">Client-side ZIP extraction to browser storage</p>
            </div>
          </div>

          {!isProcessing && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Why Browser Storage Banner */}
        <div className="my-4 p-3 rounded-2xl bg-indigo-950/40 border border-indigo-500/20 flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
          <p className="text-xs text-indigo-200/90 leading-relaxed">
            <strong>Keeps your phone clean:</strong> Recordings are extracted directly inside
            your browser's private offline storage. Your phone's media library and gallery will
            never get cluttered with these files!
          </p>
        </div>

        {/* Active Progress State */}
        {isProcessing && progress ? (
          <div className="py-8 px-2 space-y-4 text-center">
            <div className="w-16 h-16 rounded-full bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center mx-auto text-cyan-400 animate-spin">
              <Loader2 className="w-8 h-8" />
            </div>

            <div>
              <p className="text-sm font-semibold text-slate-100 capitalize">
                {progress.stage === 'reading'
                  ? 'Reading Archive...'
                  : progress.stage === 'saving'
                  ? 'Saving to Offline Vault...'
                  : 'Extracting Recordings...'}
              </p>
              <p className="text-xs text-slate-400 mt-1 truncate max-w-xs mx-auto">
                {progress.currentFileName}
              </p>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-800 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-gradient-to-r from-cyan-400 to-indigo-500 h-full transition-all duration-200"
                style={{ width: `${progress.percentage}%` }}
              />
            </div>

            <div className="flex justify-between text-[11px] font-mono text-slate-400 px-1">
              <span>{progress.percentage}% complete</span>
              {progress.totalFiles > 0 && (
                <span>
                  {progress.extractedFiles} of {progress.totalFiles} files
                </span>
              )}
            </div>
          </div>
        ) : successCount !== null ? (
          /* Success Screen */
          <div className="py-6 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center mx-auto text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <div>
              <h4 className="text-lg font-bold text-slate-100">Extraction Complete!</h4>
              <p className="text-sm text-slate-300 mt-1">
                Successfully stored <strong className="text-cyan-400">{successCount} recordings</strong> in your offline vault.
              </p>
            </div>
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm transition shadow-lg shadow-cyan-500/25"
            >
              Start Listening Now
            </button>
          </div>
        ) : (
          /* Upload drop area */
          <div className="space-y-4">
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/40 text-xs text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Drag & Drop Box */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => zipInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 sm:p-8 text-center cursor-pointer transition flex flex-col items-center justify-center ${
                isDragging
                  ? 'border-cyan-400 bg-cyan-500/10'
                  : 'border-slate-700 hover:border-cyan-500/50 hover:bg-slate-800/50 bg-slate-900/40'
              }`}
            >
              <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-3">
                <Upload className="w-7 h-7" />
              </div>
              <p className="text-sm font-semibold text-slate-200">
                Drop your <span className="text-cyan-400">.ZIP</span> archive here
              </p>
              <p className="text-xs text-slate-400 mt-1">
                or click to browse your ZIP file with recordings
              </p>
              <span className="mt-3 px-3 py-1 rounded-full text-[11px] font-mono text-slate-400 bg-slate-800 border border-slate-700">
                Supports .zip with MP3, WAV, M4A, OGG, AAC
              </span>
            </div>

            {/* Alternative options: Folder or individual audio files */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                onClick={() => folderInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition"
              >
                <FolderUp className="w-4 h-4 text-amber-400" />
                <span>Select Folder</span>
              </button>

              <button
                onClick={() => filesInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition"
              >
                <FileAudio className="w-4 h-4 text-cyan-400" />
                <span>Audio Files</span>
              </button>
            </div>

            {/* Quick Demo Button */}
            <div className="pt-2 border-t border-slate-800/80 text-center">
              <button
                onClick={handleLoadDemo}
                className="inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-medium py-1 px-3 rounded-lg hover:bg-cyan-500/10 transition"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Or load sample voice recordings to test immediately</span>
              </button>
            </div>

            {/* Hidden file inputs */}
            <input
              ref={zipInputRef}
              type="file"
              accept=".zip,application/zip"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  handleProcessZip(e.target.files[0]);
                }
              }}
            />
            <input
              ref={filesInputRef}
              type="file"
              accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac,.opus,.webm"
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  handleProcessFiles(e.target.files);
                }
              }}
            />
            <input
              ref={folderInputRef}
              type="file"
              // @ts-expect-error webkitdirectory is standard in Chromium/modern browsers
              webkitdirectory=""
              directory=""
              multiple
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  handleProcessFiles(e.target.files);
                }
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
};
