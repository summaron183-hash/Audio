import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Search, X, Play, Music, Folder, Clock, ArrowLeft, CornerDownLeft } from 'lucide-react';
import { AudioTrack } from '../types';
import { usePlayer } from '../context/PlayerContext';

interface GlobalSearchProps {
  tracks: AudioTrack[];
  onSelectTrack: (track: AudioTrack) => void;
  onNavigateFolder?: (folderPath: string) => void;
  className?: string;
}

function formatDuration(sec: number): string {
  if (!sec || !Number.isFinite(sec)) return '--:--';
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return `${m}:${s < 10 ? '0' : ''}${s}`;
}

// Highlights matching substring safely
function HighlightedText({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <span>{text}</span>;

  const parts = text.split(new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi'));
  return (
    <span>
      {parts.map((part, i) =>
        part.toLowerCase() === query.toLowerCase() ? (
          <span key={i} className="text-cyan-400 font-semibold underline decoration-cyan-500/50">
            {part}
          </span>
        ) : (
          part
        )
      )}
    </span>
  );
}

export const GlobalSearch: React.FC<GlobalSearchProps> = ({
  tracks,
  onSelectTrack,
  onNavigateFolder,
  className = '',
}) => {
  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { playTrack } = usePlayer();

  const handleClose = () => {
    setIsOpen(false);
    inputRef.current?.blur();
  };

  // Keyboard shortcut Ctrl+K or '/' to focus search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsOpen(true);
        setTimeout(() => inputRef.current?.focus(), 50);
      } else if (e.key === '/' && document.activeElement !== inputRef.current) {
        if (
          document.activeElement?.tagName !== 'INPUT' &&
          document.activeElement?.tagName !== 'TEXTAREA'
        ) {
          e.preventDefault();
          setIsOpen(true);
          setTimeout(() => inputRef.current?.focus(), 50);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Compute suggestions "around the audio name" (fuzzy & token matching across thousands of tracks)
  const suggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const tokens = q.split(/\s+/).filter(Boolean);

    const scored = tracks
      .map((track) => {
        const titleLower = track.title.toLowerCase();
        const nameLower = track.name.toLowerCase();
        const folderLower = track.folder.toLowerCase();

        // Exact match
        if (titleLower === q || nameLower === q) return { track, score: 100 };

        // Starts with match
        if (titleLower.startsWith(q) || nameLower.startsWith(q)) return { track, score: 80 };

        // Substring match in title
        if (titleLower.includes(q)) return { track, score: 60 };

        // Substring match in raw filename
        if (nameLower.includes(q)) return { track, score: 50 };

        // Multi-token match
        const allTokensFound = tokens.every(
          (tok) =>
            titleLower.includes(tok) ||
            nameLower.includes(tok) ||
            folderLower.includes(tok)
        );
        if (allTokensFound) return { track, score: 40 };

        // Folder match
        if (folderLower.includes(q)) return { track, score: 25 };

        return null;
      })
      .filter((item): item is { track: AudioTrack; score: number } => item !== null)
      .sort((a, b) => b.score - a.score)
      .slice(0, 15);

    return scored.map((s) => s.track);
  }, [tracks, query]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      handleClose();
      return;
    }

    if (!isOpen || suggestions.length === 0) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % suggestions.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + suggestions.length) % suggestions.length);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const chosen = suggestions[selectedIndex];
      if (chosen) {
        handlePlayTrack(chosen);
      }
    }
  };

  const handlePlayTrack = (track: AudioTrack) => {
    playTrack(track, suggestions);
    onSelectTrack(track);
    handleClose();
  };

  return (
    <>
      {/* Background Dim Backdrop when Search Bar gets BIG */}
      {isOpen && (
        <div
          onClick={handleClose}
          className="fixed inset-0 z-40 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200"
        />
      )}

      {/* Main Search Container: Compact in header, or BIG modal-style when open */}
      <div
        ref={containerRef}
        className={`transition-all duration-300 ease-out ${
          isOpen
            ? 'fixed inset-x-3 sm:inset-x-8 top-3 sm:top-5 max-w-4xl mx-auto z-50'
            : `relative w-full max-w-xs sm:max-w-md ${className}`
        }`}
      >
        <div
          className={`relative flex items-center transition-all duration-300 ${
            isOpen
              ? 'rounded-3xl bg-slate-900 border-2 border-cyan-400 shadow-2xl shadow-cyan-950/60 ring-4 ring-cyan-500/20'
              : 'rounded-2xl bg-slate-900/90 hover:bg-slate-900 border border-slate-700/80 hover:border-slate-600'
          }`}
        >
          {/* Back button when BIG, or Search icon when small */}
          {isOpen ? (
            <button
              onClick={handleClose}
              className="absolute left-3.5 p-1.5 rounded-xl bg-slate-800 text-cyan-300 hover:text-white hover:bg-slate-700 transition"
              title="Back (Close search)"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : (
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
          )}

          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onClick={() => setIsOpen(true)}
            onFocus={() => setIsOpen(true)}
            onKeyDown={handleKeyDown}
            placeholder={
              isOpen
                ? 'Type recording title, lecture topic, or keywords... (Press Esc or ← to go back)'
                : 'Search recordings... (Press / to search)'
            }
            className={`w-full bg-transparent text-slate-100 placeholder-slate-400 outline-none transition-all duration-200 ${
              isOpen
                ? 'py-4 pl-14 pr-24 text-base sm:text-lg font-medium'
                : 'py-2.5 pl-10 pr-20 text-sm'
            }`}
          />

          {/* Right Action: Clear or Back or '/' shortcut */}
          <div className="absolute right-3 flex items-center gap-2">
            {query && (
              <button
                onClick={() => {
                  setQuery('');
                  inputRef.current?.focus();
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
                title="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            {isOpen ? (
              <button
                onClick={handleClose}
                className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Close
              </button>
            ) : (
              <kbd className="hidden sm:inline-block px-2 py-0.5 text-[11px] font-mono text-slate-400 bg-slate-800/80 border border-slate-700 rounded-lg shadow-sm">
                /
              </kbd>
            )}
          </div>
        </div>

        {/* Big Search Results Dropdown */}
        {isOpen && (
          <div className="mt-2.5 bg-slate-900/98 backdrop-blur-2xl border border-slate-700/90 rounded-3xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-top-3 duration-200">
            {query.trim().length > 0 ? (
              <>
                <div className="px-5 py-3 border-b border-slate-800 flex items-center justify-between text-xs text-slate-400 bg-slate-950/50">
                  <span className="font-semibold text-cyan-300 flex items-center gap-1.5">
                    <span>Search Results for "{query}"</span>
                  </span>
                  <span className="text-[11px] font-mono">
                    {suggestions.length} {suggestions.length === 1 ? 'recording' : 'recordings'} found
                  </span>
                </div>

                {suggestions.length === 0 ? (
                  <div className="py-12 px-4 text-center">
                    <Music className="w-10 h-10 text-slate-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-slate-300">
                      No recording found around "{query}"
                    </p>
                    <p className="text-xs text-slate-400 mt-1">
                      Try searching with partial words, topics, or folder keywords
                    </p>
                  </div>
                ) : (
                  <div className="max-h-[55vh] overflow-y-auto divide-y divide-slate-800/60 p-1">
                    {suggestions.map((track, idx) => {
                      const isSelected = idx === selectedIndex;
                      return (
                        <div
                          key={track.id}
                          onMouseEnter={() => setSelectedIndex(idx)}
                          onClick={() => handlePlayTrack(track)}
                          className={`flex items-center gap-3.5 px-4 py-3 rounded-2xl cursor-pointer transition ${
                            isSelected
                              ? 'bg-gradient-to-r from-cyan-950/80 via-slate-800 to-indigo-950/80 border border-cyan-500/30 shadow-md'
                              : 'hover:bg-slate-800/50'
                          }`}
                        >
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handlePlayTrack(track);
                            }}
                            className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 flex items-center justify-center shrink-0 transition shadow-sm"
                            title="Play now"
                          >
                            <Play className="w-4 h-4 fill-current ml-0.5" />
                          </button>

                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-bold text-slate-100 truncate">
                              <HighlightedText text={track.title} query={query} />
                            </div>
                            <div className="flex items-center gap-2.5 mt-0.5 text-xs text-slate-400">
                              <span className="flex items-center gap-1 truncate text-slate-400 hover:text-cyan-300">
                                <Folder className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                                <HighlightedText text={track.folder || 'Vault'} query={query} />
                              </span>
                              <span>•</span>
                              <span className="flex items-center gap-1 shrink-0 text-slate-400">
                                <Clock className="w-3.5 h-3.5" />
                                {formatDuration(track.duration)}
                              </span>
                              {track.subtitles && track.subtitles.length > 0 && (
                                <>
                                  <span>•</span>
                                  <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                                    Subtitles
                                  </span>
                                </>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            {onNavigateFolder && track.folder && track.folder !== 'Root' && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  onNavigateFolder(track.folder);
                                  handleClose();
                                }}
                                className="hidden sm:inline-flex items-center text-xs px-2.5 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition"
                                title="Open in Folder View"
                              >
                                View Folder
                              </button>
                            )}

                            <div className="hidden md:flex items-center gap-1 text-[11px] text-slate-400">
                              <kbd className="px-1.5 py-0.5 bg-slate-800 rounded text-slate-300">↵</kbd>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </>
            ) : (
              /* When Big Search Bar is clicked before typing: Helpful prompt */
              <div className="p-6 text-center space-y-2">
                <p className="text-sm font-semibold text-slate-200">
                  Search across all {tracks.length} recordings in your vault
                </p>
                <p className="text-xs text-slate-400">
                  Type any part of the recording name, subject, or lecture title. Click background or Back (←) to exit.
                </p>
              </div>
            )}

            <div className="px-4 py-2 bg-slate-950/70 border-t border-slate-800/70 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-2">
                <span>Navigate with <kbd className="px-1 py-0.5 bg-slate-800 rounded">↑</kbd> <kbd className="px-1 py-0.5 bg-slate-800 rounded">↓</kbd></span>
                <span>•</span>
                <span>Press <kbd className="px-1 py-0.5 bg-slate-800 rounded">Esc</kbd> to exit</span>
              </span>
              <span className="text-slate-400 font-medium">
                Created by Meheraj
              </span>
            </div>
          </div>
        )}
      </div>
    </>
  );
};
