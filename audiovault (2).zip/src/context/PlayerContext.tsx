import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback,
  useMemo,
} from 'react';
import { AudioTrack, PlaybackRepeat, PlayerState, EqualizerBand, EqualizerPreset } from '../types';
import { getAudioBlob, updateTrack, saveTrackSubtitles } from '../services/storage';
import { generateAndCacheSubtitles, parseSrtOrVtt, SubtitleCue } from '../services/subtitles';

const EQ_FREQUENCIES = [
  { freq: 60, label: '60 Hz', type: 'lowshelf' as BiquadFilterType },
  { freq: 230, label: '230 Hz', type: 'peaking' as BiquadFilterType },
  { freq: 910, label: '910 Hz', type: 'peaking' as BiquadFilterType },
  { freq: 3600, label: '3.6 kHz', type: 'peaking' as BiquadFilterType },
  { freq: 14000, label: '14 kHz', type: 'highshelf' as BiquadFilterType },
];

export const EQ_PRESETS: EqualizerPreset[] = [
  { name: 'Flat / Default', gains: [0, 0, 0, 0, 0] },
  { name: 'Lecture / Speech Clarity', gains: [-4, -1, 4, 5, 2] },
  { name: 'Bass Boost', gains: [6, 4, 0, -1, -2] },
  { name: 'Vocal Booster', gains: [-2, 1, 5, 4, 1] },
  { name: 'Treble Boost', gains: [-3, 0, 1, 4, 6] },
  { name: 'Podcast / Voice Note', gains: [-5, 0, 5, 4, 0] },
  { name: 'Acoustic / Warm', gains: [3, 2, 0, 2, 3] },
];

interface PlayerContextType extends PlayerState {
  playTrack: (track: AudioTrack, newQueue?: AudioTrack[]) => Promise<void>;
  togglePlayPause: () => void;
  pause: () => void;
  resume: () => void;
  seek: (seconds: number) => void;
  seekRelative: (deltaSeconds: number) => void;
  setVolume: (val: number) => void;
  toggleMute: () => void;
  setPlaybackRate: (rate: number) => void;
  toggleRepeat: () => void;
  toggleShuffle: () => void;
  playNext: () => void;
  playPrev: () => void;
  setQueue: (queue: AudioTrack[], startIndex?: number) => void;
  activeUrl: string | null;
  audioRef: React.RefObject<HTMLAudioElement | null>;
  isExpanded: boolean;
  setIsExpanded: (expanded: boolean) => void;

  // Sound Controller / Equalizer
  eqBands: EqualizerBand[];
  setEqGain: (freq: number, gain: number) => void;
  selectedPreset: string;
  applyEqPreset: (presetName: string) => void;
  resetEq: () => void;

  // Subtitles
  subtitles: SubtitleCue[];
  activeSubtitle: SubtitleCue | null;
  showSubtitles: boolean;
  setShowSubtitles: (show: boolean) => void;
  isTranscribing: boolean;
  transcriptionError: string | null;
  downloadSubtitlesForCurrent: () => Promise<void>;
  importSubtitleFile: (file: File) => Promise<void>;
}

const PlayerContext = createContext<PlayerContextType | null>(null);

export const PlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const currentBlobUrlRef = useRef<string | null>(null);

  // Web Audio Equalizer nodes
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const filterNodesRef = useRef<Map<number, BiquadFilterNode>>(new Map());

  const [currentTrack, setCurrentTrack] = useState<AudioTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(() => {
    const saved = localStorage.getItem('vv_volume');
    return saved !== null ? parseFloat(saved) : 0.85;
  });
  const [isMuted, setIsMuted] = useState(false);
  const [playbackRate, setPlaybackRateState] = useState(() => {
    const saved = localStorage.getItem('vv_playbackRate');
    return saved !== null ? parseFloat(saved) : 1.0;
  });
  const [repeat, setRepeat] = useState<PlaybackRepeat>(() => {
    return (localStorage.getItem('vv_repeat') as PlaybackRepeat) || 'all';
  });
  const [isShuffle, setIsShuffle] = useState(() => {
    return localStorage.getItem('vv_shuffle') === 'true';
  });
  const [queue, setQueueState] = useState<AudioTrack[]>([]);
  const [queueIndex, setQueueIndex] = useState(-1);
  const [isExpanded, setIsExpanded] = useState(false);

  // Sound Controller / EQ State
  const [eqGains, setEqGains] = useState<{ [freq: number]: number }>(() => {
    try {
      const saved = localStorage.getItem('vv_eq_gains');
      if (saved) return JSON.parse(saved);
    } catch {}
    return { 60: 0, 230: 0, 910: 0, 3600: 0, 14000: 0 };
  });
  const [selectedPreset, setSelectedPreset] = useState<string>(() => {
    return localStorage.getItem('vv_eq_preset') || 'Flat / Default';
  });

  // Subtitles State
  const [subtitles, setSubtitles] = useState<SubtitleCue[]>([]);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [transcriptionError, setTranscriptionError] = useState<string | null>(null);

  // Initialize Web Audio & Audio element
  useEffect(() => {
    const audio = new Audio();
    audio.preload = 'metadata';
    audio.volume = volume;
    audio.playbackRate = playbackRate;
    audioRef.current = audio;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      if ('mediaSession' in navigator && 'setPositionState' in navigator.mediaSession) {
        if (Number.isFinite(audio.duration) && audio.duration > 0) {
          try {
            navigator.mediaSession.setPositionState({
              duration: audio.duration,
              playbackRate: audio.playbackRate,
              position: Math.min(audio.currentTime, audio.duration),
            });
          } catch {}
        }
      }
    };

    const handleLoadedMetadata = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        setDuration(audio.duration);
      }
    };

    const handleDurationChange = () => {
      if (Number.isFinite(audio.duration) && audio.duration > 0) {
        setDuration(audio.duration);
      }
    };

    const handlePlay = () => {
      setIsPlaying(true);
      // Resume AudioContext on user interaction if suspended
      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume().catch(() => {});
      }
    };
    const handlePause = () => setIsPlaying(false);

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.pause();
      if (currentBlobUrlRef.current) {
        URL.revokeObjectURL(currentBlobUrlRef.current);
      }
    };
  }, []);

  // Setup Web Audio Equalizer Pipeline
  const initAudioGraph = useCallback(() => {
    if (audioContextRef.current || !audioRef.current) return;

    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const source = ctx.createMediaElementSource(audioRef.current);
      sourceNodeRef.current = source;

      // Create chain of 5 BiquadFilterNodes
      let lastNode: AudioNode = source;

      EQ_FREQUENCIES.forEach(({ freq, type }) => {
        const filter = ctx.createBiquadFilter();
        filter.type = type;
        filter.frequency.value = freq;
        filter.gain.value = eqGains[freq] ?? 0;
        filterNodesRef.current.set(freq, filter);

        lastNode.connect(filter);
        lastNode = filter;
      });

      lastNode.connect(ctx.destination);
    } catch (err) {
      console.warn('Web Audio Equalizer initialization note:', err);
    }
  }, [eqGains]);

  // Update MediaSession lock-screen controls
  const updateMediaSession = useCallback((track: AudioTrack) => {
    if (!('mediaSession' in navigator)) return;

    const folderName =
      track.folder && track.folder !== 'Root' ? track.folder : 'VocalVault Archive';

    navigator.mediaSession.metadata = new MediaMetadata({
      title: track.title || track.name,
      artist: `${folderName} • by Meheraj`,
      album: 'VocalVault Archive',
      artwork: [
        { src: '/pwa-192x192.png', sizes: '192x192', type: 'image/png' },
        { src: '/pwa-512x512.png', sizes: '512x512', type: 'image/png' },
      ],
    });
  }, []);

  // Play next track callback
  const playNext = useCallback(() => {
    if (queue.length === 0) return;

    if (repeat === 'one' && currentTrack) {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(() => {});
      }
      return;
    }

    let nextIdx: number;
    if (isShuffle) {
      if (queue.length === 1) {
        nextIdx = 0;
      } else {
        do {
          nextIdx = Math.floor(Math.random() * queue.length);
        } while (nextIdx === queueIndex && queue.length > 1);
      }
    } else {
      nextIdx = queueIndex + 1;
      if (nextIdx >= queue.length) {
        if (repeat === 'all') {
          nextIdx = 0;
        } else {
          setIsPlaying(false);
          return;
        }
      }
    }

    const nextTrack = queue[nextIdx];
    if (nextTrack) {
      setQueueIndex(nextIdx);
      playTrackDirect(nextTrack);
    }
  }, [queue, queueIndex, repeat, isShuffle, currentTrack]);

  // Play prev track callback
  const playPrev = useCallback(() => {
    if (queue.length === 0) return;

    if (audioRef.current && audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }

    let prevIdx = queueIndex - 1;
    if (prevIdx < 0) {
      prevIdx = repeat === 'all' ? queue.length - 1 : 0;
    }

    const prevTrack = queue[prevIdx];
    if (prevTrack) {
      setQueueIndex(prevIdx);
      playTrackDirect(prevTrack);
    }
  }, [queue, queueIndex, repeat]);

  // Audio onended handler
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleEnded = () => {
      playNext();
    };

    audio.addEventListener('ended', handleEnded);
    return () => audio.removeEventListener('ended', handleEnded);
  }, [playNext]);

  // Attach MediaSession action handlers
  useEffect(() => {
    if (!('mediaSession' in navigator)) return;

    try {
      navigator.mediaSession.setActionHandler('play', () => {
        audioRef.current?.play().catch(() => {});
      });
      navigator.mediaSession.setActionHandler('pause', () => {
        audioRef.current?.pause();
      });
      navigator.mediaSession.setActionHandler('previoustrack', () => {
        playPrev();
      });
      navigator.mediaSession.setActionHandler('nexttrack', () => {
        playNext();
      });
      navigator.mediaSession.setActionHandler('seekbackward', (details) => {
        const skip = details.seekOffset || 10;
        if (audioRef.current) {
          audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - skip);
        }
      });
      navigator.mediaSession.setActionHandler('seekforward', (details) => {
        const skip = details.seekOffset || 10;
        if (audioRef.current) {
          audioRef.current.currentTime = Math.min(
            audioRef.current.duration || 0,
            audioRef.current.currentTime + skip
          );
        }
      });
      navigator.mediaSession.setActionHandler('seekto', (details) => {
        if (audioRef.current && details.seekTime !== undefined && details.seekTime !== null) {
          audioRef.current.currentTime = details.seekTime;
        }
      });
    } catch {}
  }, [playNext, playPrev]);

  // Low-level track play from blob
  const playTrackDirect = async (track: AudioTrack) => {
    const audio = audioRef.current;
    if (!audio) return;

    try {
      // Connect Web Audio Equalizer graph
      initAudioGraph();
      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume().catch(() => {});
      }

      const blob = await getAudioBlob(track.id);
      if (!blob) {
        console.error('Audio blob not found in IndexedDB for track:', track.id);
        return;
      }

      if (currentBlobUrlRef.current) {
        URL.revokeObjectURL(currentBlobUrlRef.current);
      }

      const objectUrl = URL.createObjectURL(blob);
      currentBlobUrlRef.current = objectUrl;

      audio.src = objectUrl;
      audio.playbackRate = playbackRate;
      audio.volume = isMuted ? 0 : volume;

      setCurrentTrack(track);
      setCurrentTime(0);
      setDuration(track.duration || 0);

      // Load subtitles if track has them stored offline
      setSubtitles(track.subtitles || []);
      setTranscriptionError(null);

      updateMediaSession(track);

      await audio.play();
      setIsPlaying(true);

      const updated: AudioTrack = {
        ...track,
        playCount: (track.playCount || 0) + 1,
        lastPlayed: Date.now(),
      };
      updateTrack(updated).catch(() => {});
    } catch (err) {
      console.warn('Audio play request failed or was interrupted:', err);
    }
  };

  // High-level public playTrack
  const playTrack = async (track: AudioTrack, newQueue?: AudioTrack[]) => {
    if (newQueue && newQueue.length > 0) {
      setQueueState(newQueue);
      const idx = newQueue.findIndex((t) => t.id === track.id);
      setQueueIndex(idx >= 0 ? idx : 0);
    } else if (queue.length === 0) {
      setQueueState([track]);
      setQueueIndex(0);
    } else {
      const idx = queue.findIndex((t) => t.id === track.id);
      if (idx >= 0) {
        setQueueIndex(idx);
      } else {
        const updated = [...queue, track];
        setQueueState(updated);
        setQueueIndex(updated.length - 1);
      }
    }

    await playTrackDirect(track);
  };

  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (!audio) return;

    initAudioGraph();
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume().catch(() => {});
    }

    if (isPlaying) {
      audio.pause();
    } else {
      audio.play().catch(() => {});
    }
  };

  const pause = () => audioRef.current?.pause();
  const resume = () => audioRef.current?.play().catch(() => {});

  const seek = (seconds: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    const clamped = Math.max(0, Math.min(seconds, audio.duration || seconds));
    audio.currentTime = clamped;
    setCurrentTime(clamped);
  };

  const seekRelative = (deltaSeconds: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    const newTime = Math.max(0, Math.min(audio.currentTime + deltaSeconds, audio.duration || 0));
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const setVolume = (val: number) => {
    const clamped = Math.max(0, Math.min(val, 1));
    setVolumeState(clamped);
    localStorage.setItem('vv_volume', clamped.toString());
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : clamped;
    }
  };

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    if (audioRef.current) {
      audioRef.current.volume = nextMuted ? 0 : volume;
    }
  };

  const setPlaybackRate = (rate: number) => {
    const clamped = Math.max(0.5, Math.min(rate, 2.5));
    setPlaybackRateState(clamped);
    localStorage.setItem('vv_playbackRate', clamped.toString());
    if (audioRef.current) {
      audioRef.current.playbackRate = clamped;
    }
    if ('mediaSession' in navigator && 'setPositionState' in navigator.mediaSession) {
      if (audioRef.current && audioRef.current.duration) {
        try {
          navigator.mediaSession.setPositionState({
            duration: audioRef.current.duration,
            playbackRate: clamped,
            position: audioRef.current.currentTime,
          });
        } catch {}
      }
    }
  };

  const toggleRepeat = () => {
    const modes: PlaybackRepeat[] = ['off', 'all', 'one'];
    const next = modes[(modes.indexOf(repeat) + 1) % modes.length];
    setRepeat(next);
    localStorage.setItem('vv_repeat', next);
  };

  const toggleShuffle = () => {
    const next = !isShuffle;
    setIsShuffle(next);
    localStorage.setItem('vv_shuffle', next.toString());
  };

  const setQueue = (newQueue: AudioTrack[], startIndex = 0) => {
    setQueueState(newQueue);
    setQueueIndex(startIndex);
  };

  // Equalizer functions
  const setEqGain = (freq: number, gain: number) => {
    initAudioGraph();
    const clamped = Math.max(-12, Math.min(12, gain));
    setEqGains((prev) => {
      const updated = { ...prev, [freq]: clamped };
      localStorage.setItem('vv_eq_gains', JSON.stringify(updated));
      return updated;
    });

    const filter = filterNodesRef.current.get(freq);
    if (filter) {
      filter.gain.value = clamped;
    }
    setSelectedPreset('Custom');
  };

  const applyEqPreset = (presetName: string) => {
    initAudioGraph();
    const preset = EQ_PRESETS.find((p) => p.name === presetName);
    if (!preset) return;

    const updated: { [freq: number]: number } = {};
    EQ_FREQUENCIES.forEach(({ freq }, idx) => {
      const g = preset.gains[idx] ?? 0;
      updated[freq] = g;
      const filter = filterNodesRef.current.get(freq);
      if (filter) {
        filter.gain.value = g;
      }
    });

    setEqGains(updated);
    setSelectedPreset(presetName);
    localStorage.setItem('vv_eq_gains', JSON.stringify(updated));
    localStorage.setItem('vv_eq_preset', presetName);
  };

  const resetEq = () => {
    applyEqPreset('Flat / Default');
  };

  // Compute active subtitle cue for currentTime
  const activeSubtitle = useMemo(() => {
    if (!subtitles || subtitles.length === 0) return null;
    return (
      subtitles.find(
        (cue) => cue.start <= currentTime && currentTime <= cue.end + 0.3
      ) || null
    );
  }, [subtitles, currentTime]);

  // Download English subtitles for current track
  const downloadSubtitlesForCurrent = async () => {
    if (!currentTrack) return;
    setIsTranscribing(true);
    setTranscriptionError(null);

    try {
      const newSubtitles = await generateAndCacheSubtitles(currentTrack);
      setSubtitles(newSubtitles);
      setCurrentTrack((prev) => (prev ? { ...prev, subtitles: newSubtitles } : null));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Transcription failed';
      setTranscriptionError(msg);
    } finally {
      setIsTranscribing(false);
    }
  };

  // Import custom .srt / .vtt file
  const importSubtitleFile = async (file: File) => {
    if (!currentTrack) return;
    const text = await file.text();
    const parsed = parseSrtOrVtt(text);
    if (parsed.length === 0) {
      throw new Error('No valid subtitle cues found in file.');
    }
    await saveTrackSubtitles(currentTrack.id, parsed, 'file');
    setSubtitles(parsed);
    setCurrentTrack((prev) => (prev ? { ...prev, subtitles: parsed } : null));
  };

  const eqBands: EqualizerBand[] = EQ_FREQUENCIES.map(({ freq, label }) => ({
    frequency: freq,
    label,
    gain: eqGains[freq] ?? 0,
    filterNode: filterNodesRef.current.get(freq),
  }));

  return (
    <PlayerContext.Provider
      value={{
        currentTrack,
        isPlaying,
        currentTime,
        duration,
        volume,
        isMuted,
        playbackRate,
        repeat,
        isShuffle,
        queue,
        queueIndex,
        playTrack,
        togglePlayPause,
        pause,
        resume,
        seek,
        seekRelative,
        setVolume,
        toggleMute,
        setPlaybackRate,
        toggleRepeat,
        toggleShuffle,
        playNext,
        playPrev,
        setQueue,
        activeUrl: currentBlobUrlRef.current,
        audioRef,
        isExpanded,
        setIsExpanded,

        // Sound Controller / Equalizer
        eqBands,
        setEqGain,
        selectedPreset,
        applyEqPreset,
        resetEq,

        // Subtitles
        subtitles,
        activeSubtitle,
        showSubtitles,
        setShowSubtitles,
        isTranscribing,
        transcriptionError,
        downloadSubtitlesForCurrent,
        importSubtitleFile,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
};

export function usePlayer() {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error('usePlayer must be used within PlayerProvider');
  }
  return context;
}
