/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Folder,
  FolderOpen,
  Music,
  Heart,
  History,
  Archive,
  Download,
  Settings,
  Sparkles,
  ShieldCheck,
  Search,
  HardDrive,
  Gauge,
  Smartphone,
  Sliders,
  Subtitles,
} from 'lucide-react';
import { AudioTrack, ActiveTab } from './types';
import {
  getAllTracks,
  toggleFavorite,
  deleteTrack,
  deleteTracksByFolder,
  createDemoVault,
  renameTrack,
  renameFolder,
  moveTrack,
  copyTrack,
  batchDeleteTracks,
  batchMoveTracks,
  batchCopyTracks,
} from './services/storage';
import { PlayerProvider } from './context/PlayerContext';
import { GlobalSearch } from './components/GlobalSearch';
import { FolderExplorer } from './components/FolderExplorer';
import { AllTracksView } from './components/AllTracksView';
import { AudioPlayerBar } from './components/AudioPlayerBar';
import { UploadModal } from './components/UploadModal';
import { InstallModal } from './components/InstallModal';
import { SettingsModal } from './components/SettingsModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { usePWAInstall } from './hooks/usePWAInstall';

function MainLayout() {
  const [tracks, setTracks] = useState<AudioTrack[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<ActiveTab>('explorer');
  const [currentFolder, setCurrentFolder] = useState<string>('Root');

  // Custom created folders (even if currently empty)
  const [createdFolders, setCreatedFolders] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('vv_custom_folders');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Modals
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isInstallOpen, setIsInstallOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    confirmLabel: string;
    onConfirm: () => Promise<void> | void;
  } | null>(null);

  const { isInstallable, isInstalled } = usePWAInstall();

  // Load tracks from IndexedDB
  const refreshTracks = useCallback(async () => {
    try {
      const all = await getAllTracks();
      setTracks(all);
    } catch (err) {
      console.error('Failed to load tracks from IndexedDB:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshTracks();
  }, [refreshTracks]);

  // Handle favorite toggle
  const handleToggleFavorite = async (trackId: string) => {
    await toggleFavorite(trackId);
    setTracks((prev) =>
      prev.map((t) => (t.id === trackId ? { ...t, favorite: !t.favorite } : t))
    );
  };

  // Handle track delete
  const handleDeleteTrack = async (trackId: string) => {
    setConfirmDialog({
      title: 'Delete Recording',
      message: 'Are you sure you want to delete this recording from your offline vault?',
      confirmLabel: 'Delete Recording',
      onConfirm: async () => {
        await deleteTrack(trackId);
        setTracks((prev) => prev.filter((t) => t.id !== trackId));
        setConfirmDialog(null);
      },
    });
  };

  // Handle folder delete
  const handleDeleteFolder = async (folderPath: string) => {
    setConfirmDialog({
      title: 'Delete Entire Folder',
      message: `Delete folder "${folderPath}" and all recordings inside it? This cannot be undone.`,
      confirmLabel: 'Delete Entire Folder',
      onConfirm: async () => {
        await deleteTracksByFolder(folderPath);
        setCreatedFolders((prev) => {
          const updated = prev.filter(
            (f) => f !== folderPath && !f.startsWith(folderPath + '/')
          );
          localStorage.setItem('vv_custom_folders', JSON.stringify(updated));
          return updated;
        });
        await refreshTracks();
        setCurrentFolder('Root');
        setConfirmDialog(null);
      },
    });
  };

  // Handle rename track
  const handleRenameTrack = async (trackId: string, newTitle: string) => {
    await renameTrack(trackId, newTitle);
    await refreshTracks();
  };

  // Handle rename folder
  const handleRenameFolder = async (oldFolder: string, newFolder: string) => {
    await renameFolder(oldFolder, newFolder);
    setCreatedFolders((prev) => {
      const updated = prev.map((f) => {
        if (f === oldFolder) return newFolder;
        if (f.startsWith(oldFolder + '/')) {
          return newFolder + f.slice(oldFolder.length);
        }
        return f;
      });
      localStorage.setItem('vv_custom_folders', JSON.stringify(updated));
      return updated;
    });
    await refreshTracks();
    if (currentFolder === oldFolder) setCurrentFolder(newFolder);
  };

  // Handle move track
  const handleMoveTrack = async (trackId: string, dest: string) => {
    await moveTrack(trackId, dest);
    await refreshTracks();
  };

  // Handle copy track
  const handleCopyTrack = async (trackId: string, dest: string) => {
    await copyTrack(trackId, dest);
    await refreshTracks();
  };

  // Handle batch operations
  const handleBatchDelete = async (trackIds: string[]) => {
    await batchDeleteTracks(trackIds);
    await refreshTracks();
  };

  const handleBatchMove = async (trackIds: string[], dest: string) => {
    await batchMoveTracks(trackIds, dest);
    await refreshTracks();
  };

  const handleBatchCopy = async (trackIds: string[], dest: string) => {
    await batchCopyTracks(trackIds, dest);
    await refreshTracks();
  };

  // Handle create folder
  const handleCreateFolder = (newFolderPath: string) => {
    setCreatedFolders((prev) => {
      const updated = Array.from(new Set([...prev, newFolderPath]));
      localStorage.setItem('vv_custom_folders', JSON.stringify(updated));
      return updated;
    });
    setCurrentFolder(newFolderPath);
  };

  // Handle demo import
  const handleLoadDemoTracks = async () => {
    setLoading(true);
    await createDemoVault();
    await refreshTracks();
    setLoading(false);
  };

  // Compute all unique folder paths
  const allFolderPaths = useMemo(() => {
    const set = new Set<string>(createdFolders);
    tracks.forEach((t) => {
      if (t.folder && t.folder !== 'Root') set.add(t.folder);
    });
    return Array.from(set).sort();
  }, [tracks, createdFolders]);

  const favorites = tracks.filter((t) => t.favorite);
  const recents = tracks
    .filter((t) => t.lastPlayed && t.lastPlayed > 0)
    .sort((a, b) => (b.lastPlayed || 0) - (a.lastPlayed || 0));

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans pb-28">
      {/* Offline Status Toast */}
      <OfflineIndicator />

      {/* Top Navigation Header */}
      <header className="sticky top-0 z-30 bg-slate-950/90 backdrop-blur-2xl border-b border-slate-800/80 px-4 sm:px-6 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 sm:gap-6">
          {/* Logo & Brand with "Meheraj" under the logo name */}
          <div
            onClick={() => {
              setActiveTab('explorer');
              setCurrentFolder('Root');
            }}
            className="flex items-center gap-3 cursor-pointer shrink-0 select-none group"
          >
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 p-0.5 shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <Music className="w-5 h-5 text-cyan-400 group-hover:rotate-12 transition-transform" />
              </div>
            </div>

            {/* Logo text with Meheraj under the logo name */}
            <div>
              <h1 className="font-extrabold text-base sm:text-lg tracking-tight bg-gradient-to-r from-cyan-300 via-indigo-200 to-slate-100 bg-clip-text text-transparent leading-none">
                VocalVault
              </h1>
              <p className="text-[11px] font-bold text-cyan-400 tracking-wider uppercase mt-0.5">
                Meheraj
              </p>
            </div>
          </div>

          {/* Global Search with expanding width and wide suggestions form */}
          <div className="flex-1 flex justify-center">
            <GlobalSearch
              tracks={tracks}
              onSelectTrack={() => {}}
              onNavigateFolder={(folderPath) => {
                setActiveTab('explorer');
                setCurrentFolder(folderPath);
              }}
            />
          </div>

          {/* Action Buttons: Import, Install PWA, Settings */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Upload ZIP button */}
            <button
              onClick={() => setIsUploadOpen(true)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm shadow-md shadow-cyan-500/20 transition active:scale-95"
            >
              <Archive className="w-4 h-4" />
              <span className="hidden md:inline">Import ZIP</span>
            </button>

            {/* Install Manual / PWA Shortcut */}
            <button
              onClick={() => setIsInstallOpen(true)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs sm:text-sm font-medium transition ${
                isInstallable && !isInstalled
                  ? 'bg-gradient-to-r from-indigo-950/80 to-purple-950/80 border-indigo-500/50 text-indigo-300 hover:border-indigo-400'
                  : 'bg-slate-900 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
              title="Install and Make Shortcut Manual"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span className="hidden md:inline">Install App</span>
            </button>

            {/* Settings */}
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-xl bg-slate-900 border border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-800 transition relative"
              title="Settings & Meheraj Tag"
            >
              <Settings className="w-4 h-4" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-cyan-400 ring-2 ring-slate-950" />
            </button>
          </div>
        </div>
      </header>

      {/* Sub-header Tabs & Storage summary */}
      <div className="bg-slate-950/60 border-b border-slate-800/60 px-4 sm:px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            <button
              onClick={() => setActiveTab('explorer')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition shrink-0 ${
                activeTab === 'explorer'
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <FolderOpen className="w-4 h-4" />
              <span>Folder Explorer</span>
            </button>

            <button
              onClick={() => setActiveTab('all-tracks')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition shrink-0 ${
                activeTab === 'all-tracks'
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Music className="w-4 h-4" />
              <span>All Recordings ({tracks.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('favorites')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition shrink-0 ${
                activeTab === 'favorites'
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Heart className="w-4 h-4 text-rose-400" />
              <span>Favorites ({favorites.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('recents')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs sm:text-sm font-medium transition shrink-0 ${
                activeTab === 'recents'
                  ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <History className="w-4 h-4" />
              <span>Recent Plays ({recents.length})</span>
            </button>
          </div>

          {/* Quick stats pill */}
          <div className="hidden lg:flex items-center gap-3 text-xs text-slate-400">
            <span className="flex items-center gap-1.5">
              <HardDrive className="w-3.5 h-3.5 text-cyan-400" />
              <span>
                {tracks.length} recordings across {allFolderPaths.length} folders
              </span>
            </span>
            <span>•</span>
            <span className="text-cyan-400 font-semibold">Created by Meheraj</span>
          </div>
        </div>
      </div>

      {/* Main Body */}
      <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 flex-1">
        {loading ? (
          <div className="py-24 text-center">
            <div className="w-12 h-12 rounded-full border-2 border-cyan-500 border-t-transparent animate-spin mx-auto mb-4" />
            <p className="text-sm text-slate-400">Loading your audio recordings vault...</p>
          </div>
        ) : tracks.length === 0 ? (
          /* Empty State: Hero Onboarding Screen */
          <div className="py-8 sm:py-12 max-w-4xl mx-auto">
            <div className="relative rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-700/80 p-8 sm:p-12 text-center shadow-2xl overflow-hidden">
              <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

              <div className="w-20 h-20 rounded-3xl bg-gradient-to-tr from-cyan-500 to-indigo-600 text-slate-950 flex items-center justify-center mx-auto mb-6 shadow-xl shadow-cyan-500/25">
                <Archive className="w-10 h-10" />
              </div>

              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-xs font-semibold text-cyan-300 mb-4">
                <ShieldCheck className="w-4 h-4" />
                Browser Sandboxed Storage • Created by Meheraj
              </div>

              <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-100 tracking-tight max-w-2xl mx-auto leading-tight">
                Play Large ZIP Audio Archives Without Cluttering Your Phone
              </h2>

              <p className="mt-4 text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
                When you unzip large recording archives on your phone, thousands of voice memos flood
                your gallery and personal music library. <strong className="text-cyan-400 font-semibold">VocalVault</strong> keeps
                them securely inside your browser's private offline storage with complete folder hierarchy.
              </p>

              {/* CTAs */}
              <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
                <button
                  onClick={() => setIsUploadOpen(true)}
                  className="flex items-center gap-2 px-6 py-3.5 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm sm:text-base transition shadow-xl shadow-cyan-500/30 active:scale-95"
                >
                  <Archive className="w-5 h-5" />
                  <span>Upload & Extract .ZIP Archive</span>
                </button>

                <button
                  onClick={handleLoadDemoTracks}
                  className="flex items-center gap-2 px-5 py-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-sm sm:text-base transition"
                >
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <span>Load Sample Audio Vault with Subtitles</span>
                </button>
              </div>

              {/* Feature Highlights Grid */}
              <div className="mt-12 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left">
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <Folder className="w-6 h-6 text-amber-400 mb-2" />
                  <h4 className="text-sm font-semibold text-slate-200">
                    File & Folder Manager
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Create, rename, delete, move, and copy recordings across folders.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <Sliders className="w-6 h-6 text-cyan-400 mb-2" />
                  <h4 className="text-sm font-semibold text-slate-200">
                    Sound Hz Controller
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    5-band graphic equalizer with Speech Clarity, Bass Boost, and vocal presets.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <Subtitles className="w-6 h-6 text-indigo-400 mb-2" />
                  <h4 className="text-sm font-semibold text-slate-200">
                    English Subtitles (Offline)
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Download subtitles over WiFi/data and play them in sync 100% offline anytime.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800">
                  <Smartphone className="w-6 h-6 text-purple-400 mb-2" />
                  <h4 className="text-sm font-semibold text-slate-200">
                    Lockscreen & Shortcut
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    MediaSession lock-screen controls, background playback, and PWA home-screen shortcut.
                  </p>
                </div>
              </div>

              {/* Attribution Banner */}
              <div className="mt-8 pt-6 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-center gap-2">
                <span>Created by Meheraj</span>
                <span>•</span>
                <span>Private & Sandboxed Offline Audio Vault</span>
              </div>
            </div>
          </div>
        ) : (
          /* Active Tabs View */
          <div>
            {activeTab === 'explorer' && (
              <FolderExplorer
                tracks={tracks}
                currentFolderPath={currentFolder}
                onNavigateFolder={(path) => setCurrentFolder(path)}
                onToggleFavorite={handleToggleFavorite}
                onDeleteTrack={handleDeleteTrack}
                onDeleteFolder={handleDeleteFolder}
                onRenameTrack={handleRenameTrack}
                onRenameFolder={handleRenameFolder}
                onMoveTrack={handleMoveTrack}
                onCopyTrack={handleCopyTrack}
                onCreateFolder={handleCreateFolder}
                allFolderPaths={allFolderPaths}
              />
            )}

            {activeTab === 'all-tracks' && (
              <AllTracksView
                tracks={tracks}
                onToggleFavorite={handleToggleFavorite}
                onDeleteTrack={handleDeleteTrack}
                onNavigateFolder={(folder) => {
                  setActiveTab('explorer');
                  setCurrentFolder(folder);
                }}
                onBatchDelete={handleBatchDelete}
                onBatchMove={handleBatchMove}
                onBatchCopy={handleBatchCopy}
                allFolderPaths={allFolderPaths}
                title="All Stored Audio Recordings"
              />
            )}

            {activeTab === 'favorites' && (
              <AllTracksView
                tracks={favorites}
                onToggleFavorite={handleToggleFavorite}
                onDeleteTrack={handleDeleteTrack}
                onNavigateFolder={(folder) => {
                  setActiveTab('explorer');
                  setCurrentFolder(folder);
                }}
                onBatchDelete={handleBatchDelete}
                onBatchMove={handleBatchMove}
                onBatchCopy={handleBatchCopy}
                allFolderPaths={allFolderPaths}
                title="Favorite Recordings"
                emptyMessage="No recordings marked as favorite yet. Tap the heart icon next to any recording."
              />
            )}

            {activeTab === 'recents' && (
              <AllTracksView
                tracks={recents}
                onToggleFavorite={handleToggleFavorite}
                onDeleteTrack={handleDeleteTrack}
                onNavigateFolder={(folder) => {
                  setActiveTab('explorer');
                  setCurrentFolder(folder);
                }}
                onBatchDelete={handleBatchDelete}
                onBatchMove={handleBatchMove}
                onBatchCopy={handleBatchCopy}
                allFolderPaths={allFolderPaths}
                title="Recently Played"
                emptyMessage="You haven't played any recordings yet. Select a track to start listening!"
              />
            )}
          </div>
        )}
      </main>

      {/* Footer attribution */}
      <footer className="mt-auto border-t border-slate-800/80 py-4 text-center text-xs text-slate-400">
        <p>
          VocalVault — Offline Browser-Sandboxed Audio Player •{' '}
          <strong className="text-cyan-400 font-semibold">Created by Meheraj</strong>
        </p>
      </footer>

      {/* Bottom Sticky Player Bar */}
      <AudioPlayerBar onToggleFavorite={handleToggleFavorite} />

      {/* Modals */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onImportComplete={() => {
          refreshTracks();
          setActiveTab('explorer');
        }}
      />

      <InstallModal
        isOpen={isInstallOpen}
        onClose={() => setIsInstallOpen(false)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onClearStorage={() => {
          refreshTracks();
          setCurrentFolder('Root');
        }}
      />

      {/* IN-APP CONFIRMATION MODAL */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              <span>{confirmDialog.title}</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {confirmDialog.message}
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs hover:text-white transition font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmDialog.onConfirm}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition shadow-sm"
              >
                {confirmDialog.confirmLabel}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <PlayerProvider>
      <MainLayout />
    </PlayerProvider>
  );
}
