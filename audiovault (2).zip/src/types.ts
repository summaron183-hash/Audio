export interface AudioTrack {
  id: string;
  name: string;
  title: string;
  path: string;
  folder: string;
  size: number;
  type: string;
  duration: number; // in seconds, 0 if not yet probed
  dateAdded: number;
  favorite?: boolean;
  playCount?: number;
  lastPlayed?: number;
  bookmarks?: { id: string; time: number; note: string }[];
  subtitles?: { start: number; end: number; text: string }[];
  subtitleSource?: 'offline' | 'ai' | 'file';
}

export interface EqualizerBand {
  frequency: number;
  label: string;
  gain: number; // -12dB to +12dB
  filterNode?: BiquadFilterNode;
}

export interface EqualizerPreset {
  name: string;
  gains: number[];
}

export interface FolderNode {
  name: string;
  path: string;
  trackCount: number;
  subfolders: string[];
}

export type PlaybackRepeat = 'off' | 'all' | 'one';

export interface PlayerState {
  currentTrack: AudioTrack | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  playbackRate: number;
  repeat: PlaybackRepeat;
  isShuffle: boolean;
  queue: AudioTrack[];
  queueIndex: number;
}

export type ActiveTab = 'explorer' | 'all-tracks' | 'favorites' | 'recents' | 'playlists';
