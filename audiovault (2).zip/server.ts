import express from 'express';
import http from 'http';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

// Ensure DISABLE_HMR is set in development so Vite cleanly disables HMR WebSocket
process.env.DISABLE_HMR = 'true';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize GoogleGenAI server-side with User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Subtitle generation endpoint for audio recordings
app.post('/api/transcribe', async (req, res) => {
  try {
    const { audioBase64, mimeType, trackTitle } = req.body;

    if (!audioBase64) {
      return res.status(400).json({ error: 'Audio data is required' });
    }

    const cleanMime = mimeType || 'audio/mp3';

    // Call Gemini API to transcribe with timestamped cues
    const prompt = `Transcribe this English audio recording with accurate timestamps for subtitles/closed-captions.
Return a structured JSON array where each object has:
- "start": start time in seconds (number, e.g. 0.0)
- "end": end time in seconds (number, e.g. 4.2)
- "text": English transcript for this interval (concise subtitle line)`;

    const audioPart = {
      inlineData: {
        mimeType: cleanMime,
        data: audioBase64,
      },
    };

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          audioPart,
          {
            text: prompt,
          },
        ],
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              start: { type: Type.NUMBER, description: 'Start time in seconds' },
              end: { type: Type.NUMBER, description: 'End time in seconds' },
              text: { type: Type.STRING, description: 'Spoken subtitle text' },
            },
            required: ['start', 'end', 'text'],
          },
        },
      },
    });

    const text = response.text || '[]';
    let subtitles = [];
    try {
      subtitles = JSON.parse(text);
    } catch {
      subtitles = [];
    }

    return res.json({ subtitles });
  } catch (error: unknown) {
    console.error('Error generating subtitles:', error);
    const message = error instanceof Error ? error.message : 'Transcription failed';
    return res.status(500).json({ error: message });
  }
});

async function startServer() {
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve('dist', 'index.html'));
    });
  } else {
    // In AI Studio or development, check DISABLE_HMR env var
    // In AI Studio or dev proxy environment, disable HMR websocket connection
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
        ws: false,
        watch: null,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
